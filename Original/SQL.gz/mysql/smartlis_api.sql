-- MySQL dump 10.19  Distrib 10.2.41-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: smartlis_api
-- ------------------------------------------------------
-- Server version	10.2.41-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `api_keys`
--

DROP TABLE IF EXISTS `api_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `apiKey` text NOT NULL,
  `login_id` int(11) NOT NULL,
  `ratelimit` text DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_keys`
--

LOCK TABLES `api_keys` WRITE;
/*!40000 ALTER TABLE `api_keys` DISABLE KEYS */;
INSERT INTO `api_keys` VALUES (5,'asdf','155bc64bf22fb986f8f1887705e2766f29bd264883f26bc5614bf39a6ef0d2b749edcded554899cf2ffc2795c510152b953add3d3b04643e1a4555cda1fb3e56',1,'2'),(6,'asdf','2423de82874df4b214e0db28bd70a65687830f84081dc341e42cb602925f0c5df7dccb68350f1037efb18ef1580b834dcb68aff2b1295e9293ccdd3a09a8a6d8',1,'0'),(8,'Test','4273fc129b4193910e89d9e6661be7427de4590991cb96756de052e851c8f5e5df84332595d04e40c3b7f313a5b74ce5e2120573d52445091a47690ee06debe1',1,'60'),(9,'crap','822db554fb93f52d62b583ef9142acb56c9652a0383aabeb9de44acec7d6b68804d486ce26e1833cc3adab5b40db2ad98ca09ed78b2e61c21c9296eaf7e970b5',1,'0'),(11,'Development','c07cddf2684cea9928e37afa39ba2a21844db979ae37833f6f3e66a3e87ae7f5a7421d75a064ab42b309b863049c3d73a736bab2fb68bb05101f7da4eee17fef',1,'159');
/*!40000 ALTER TABLE `api_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apps`
--

DROP TABLE IF EXISTS `apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appName` text NOT NULL,
  `redirectURI` text NOT NULL,
  `login_id` int(11) NOT NULL,
  `secret` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apps`
--

LOCK TABLES `apps` WRITE;
/*!40000 ALTER TABLE `apps` DISABLE KEYS */;
INSERT INTO `apps` VALUES (6,'Demo OAuth API','https://smartlist.ga/developer/oauth-demo/verify.php',1,'78b21e7792771f4ebfeec6cc0acf8486977764d0aba130d6e156bcf88fe335fe'),(7,'Devlist','https://devlist.rf.gd/app/login/auth.php',1,'b0079be5c41d860866eedf3e46d5ff6002712afd28333eafe6276255608492b2'),(22,'demo repl.it','https://smartlist-oauth-api-test.manuthecoder.repl.co/verify.php',1,'548fed6e7e2ad3a1cf8e1ae97bd451f5ace138f7f41d998bf53872da033cde13'),(23,'Smartlist Collaborate','https://collaborate.smartlist.ga/auth',1,'55db6d6261c510bc2c6d62702a1a80e26d6d7f54930a07fec9da5f4b1fe8a905'),(24,'Visionly','https://visionly.manuthecoder.repl.co/auth',1,'39cc714dd80ab325329f3301341761e6e2cd1ca926866cffd1325db6c8d6945c');
/*!40000 ALTER TABLE `apps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recipes`
--

DROP TABLE IF EXISTS `recipes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recipes` (
  `name` varchar(115) DEFAULT NULL,
  `url` varchar(150) DEFAULT NULL,
  `category` varchar(31) DEFAULT NULL,
  `author` varchar(40) DEFAULT NULL,
  `summary` varchar(780) DEFAULT NULL,
  `rating` decimal(3,2) DEFAULT NULL,
  `rating_count` int(5) DEFAULT NULL,
  `review_count` int(5) DEFAULT NULL,
  `ingredients` varchar(1442) DEFAULT NULL,
  `directions` varchar(4263) DEFAULT NULL,
  `prep` varchar(13) DEFAULT NULL,
  `cook` varchar(14) DEFAULT NULL,
  `total` varchar(14) DEFAULT NULL,
  `servings` int(3) DEFAULT NULL,
  `yield` varchar(51) DEFAULT NULL,
  `calories` decimal(5,1) DEFAULT NULL,
  `carbohydrates_g` decimal(4,1) DEFAULT NULL,
  `sugars_g` decimal(4,1) DEFAULT NULL,
  `fat_g` decimal(4,1) DEFAULT NULL,
  `saturated_fat_g` decimal(4,1) DEFAULT NULL,
  `cholesterol_mg` decimal(5,1) DEFAULT NULL,
  `protein_g` decimal(4,1) DEFAULT NULL,
  `dietary_fiber_g` decimal(3,1) DEFAULT NULL,
  `sodium_mg` decimal(7,1) DEFAULT NULL,
  `calories_from_fat` decimal(5,1) DEFAULT NULL,
  `calcium_mg` decimal(5,1) DEFAULT NULL,
  `iron_mg` decimal(4,1) DEFAULT NULL,
  `magnesium_mg` decimal(5,1) DEFAULT NULL,
  `potassium_mg` decimal(5,1) DEFAULT NULL,
  `zinc_mg` decimal(4,1) DEFAULT NULL,
  `phosphorus_mg` decimal(5,1) DEFAULT NULL,
  `vitamin_a_iu_IU` decimal(6,1) DEFAULT NULL,
  `niacin_equivalents_mg` decimal(4,1) DEFAULT NULL,
  `vitamin_b6_mg` varchar(10) DEFAULT NULL,
  `vitamin_c_mg` decimal(5,1) DEFAULT NULL,
  `folate_mcg` decimal(5,1) DEFAULT NULL,
  `thiamin_mg` decimal(3,1) DEFAULT NULL,
  `riboflavin_mg` decimal(2,1) DEFAULT NULL,
  `vitamin_e_iu_IU` decimal(3,1) DEFAULT NULL,
  `vitamin_k_mcg` decimal(4,1) DEFAULT NULL,
  `biotin_mcg` decimal(3,1) DEFAULT NULL,
  `vitamin_b12_mcg` varchar(10) DEFAULT NULL,
  `mono_fat_g` decimal(3,1) DEFAULT NULL,
  `poly_fat_g` decimal(3,1) DEFAULT NULL,
  `trans_fatty_acid_g` decimal(2,1) DEFAULT NULL,
  `omega_3_fatty_acid_g` varchar(10) DEFAULT NULL,
  `omega_6_fatty_acid_g` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recipes`
--

LOCK TABLES `recipes` WRITE;
/*!40000 ALTER TABLE `recipes` DISABLE KEYS */;
/*!40000 ALTER TABLE `recipes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `username` text NOT NULL,
  `user_avatar` text NOT NULL,
  `app` text NOT NULL,
  `userID` text NOT NULL,
  `color` text NOT NULL DEFAULT '#212121',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=308 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
INSERT INTO `tokens` VALUES (60,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/Cm69xM4/profile-pic.jpg','9a11641c-eb15-4abc-a403-ace711238f00','40f5888b67c748df7efba008e7c2f9d2','#37474f'),(61,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/Cm69xM4/profile-pic.jpg','b1a82fd9-7984-4d7b-856f-320b15da0f58','40f5888b67c748df7efba008e7c2f9d2','#37474f'),(63,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/Cm69xM4/profile-pic.jpg','61bb7ac2-cef5-4592-b0ae-c93e53c05ace','40f5888b67c748df7efba008e7c2f9d2','#37474f'),(65,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/Cm69xM4/profile-pic.jpg','120c41e0-ad3a-40e1-81bc-6b7b26b2ec4a','40f5888b67c748df7efba008e7c2f9d2','#37474f'),(66,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/Cm69xM4/profile-pic.jpg','1758e783-6e84-4697-b340-c1ec8e53478f','40f5888b67c748df7efba008e7c2f9d2','#37474f'),(67,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/Cm69xM4/profile-pic.jpg','f9279e13-f2dd-4216-b60a-da3d01bf46fd','40f5888b67c748df7efba008e7c2f9d2','#37474f'),(68,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/Cm69xM4/profile-pic.jpg','b7b80917-3735-48e4-ae3e-1a4afffcc5c5','40f5888b67c748df7efba008e7c2f9d2','#37474f'),(69,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/Cm69xM4/profile-pic.jpg','59c69777-48ca-4e9e-9abc-b5e53c898d9a','40f5888b67c748df7efba008e7c2f9d2','#37474f'),(70,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/Cm69xM4/profile-pic.jpg','f9c5b52c-568e-43be-9097-35015da521d5','40f5888b67c748df7efba008e7c2f9d2','#37474f'),(71,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/Cm69xM4/profile-pic.jpg','72baa2d2-ad88-4c60-8b00-52bd2f302597','40f5888b67c748df7efba008e7c2f9d2','#37474f'),(72,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/Cm69xM4/profile-pic.jpg','99a84eea-ed20-4983-8d51-f0ea679e7df6','40f5888b67c748df7efba008e7c2f9d2','#37474f'),(73,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/Cm69xM4/profile-pic.jpg','07e565e9-0343-4fde-81fa-07ce6773ca3e','40f5888b67c748df7efba008e7c2f9d2','#37474f'),(74,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/Cm69xM4/profile-pic.jpg','91a089ff-9a10-4bb7-83fe-9d0398ae6bfb','40f5888b67c748df7efba008e7c2f9d2','#37474f'),(75,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/Cm69xM4/profile-pic.jpg','023a987a-cec1-48d9-b285-84ab455563cb','40f5888b67c748df7efba008e7c2f9d2','#37474f'),(77,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/Cm69xM4/profile-pic.jpg','191b8724-84e6-4d54-adc0-4abbbf11aa4f','40f5888b67c748df7efba008e7c2f9d2','#37474f'),(78,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/Cm69xM4/profile-pic.jpg','5bf2e577-b76b-45f6-8698-da57061fdcae','40f5888b67c748df7efba008e7c2f9d2','#37474f'),(80,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/Cm69xM4/profile-pic.jpg','8432c368-2c97-42ee-b5bb-6e10b35488de','40f5888b67c748df7efba008e7c2f9d2','#37474f'),(81,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/Cm69xM4/profile-pic.jpg','da2974c1-9f36-495e-a250-2c3080a61595','40f5888b67c748df7efba008e7c2f9d2','#37474f'),(82,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/Cm69xM4/profile-pic.jpg','6f2068dc-f343-4fb3-98d4-9817c28cd928','40f5888b67c748df7efba008e7c2f9d2','#37474f'),(83,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/Cm69xM4/profile-pic.jpg','82ad0523-3e23-4424-a0d4-e868bc339474','40f5888b67c748df7efba008e7c2f9d2','#37474f'),(84,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/Cm69xM4/profile-pic.jpg','1bb8f85f-6818-4d9b-844a-f6c5d0968027','40f5888b67c748df7efba008e7c2f9d2','#37474f'),(86,'Manu G','manuthecoder@protonmail.com','Admin','//3.bp.blogspot.com/-qDc5kIFIhb8/UoJEpGN9DmI/AAAAAAABl1s/BfP6FcBY1R8/s320/BlueHead.jpg','e2a1caa5-e335-4bef-8760-0f2130491e3d','40f5888b67c748df7efba008e7c2f9d2','#2e7d32'),(87,'Manu G','manuthecoder@protonmail.com','Admin','//3.bp.blogspot.com/-qDc5kIFIhb8/UoJEpGN9DmI/AAAAAAABl1s/BfP6FcBY1R8/s320/BlueHead.jpg','ec356a47-5a2f-434f-9313-d104bb9ec18e','40f5888b67c748df7efba008e7c2f9d2','#2e7d32'),(88,'Manu G','manuthecoder@protonmail.com','Admin','//3.bp.blogspot.com/-qDc5kIFIhb8/UoJEpGN9DmI/AAAAAAABl1s/BfP6FcBY1R8/s320/BlueHead.jpg','8802598c-80db-4b97-924b-d8afa264e9e4','40f5888b67c748df7efba008e7c2f9d2','#2e7d32'),(89,'Manu G','manuthecoder@protonmail.com','Admin','//3.bp.blogspot.com/-qDc5kIFIhb8/UoJEpGN9DmI/AAAAAAABl1s/BfP6FcBY1R8/s320/BlueHead.jpg','8d5a40ba-27b2-4f0d-b7e2-b4cc7ec1fbfd','40f5888b67c748df7efba008e7c2f9d2','#2e7d32'),(90,'Manu G','manuthecoder@protonmail.com','Admin','//3.bp.blogspot.com/-qDc5kIFIhb8/UoJEpGN9DmI/AAAAAAABl1s/BfP6FcBY1R8/s320/BlueHead.jpg','cb1aa4ba-1349-49cb-a4f4-94a15538caec','40f5888b67c748df7efba008e7c2f9d2','#2e7d32'),(104,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','5457c264-0fef-4a3a-8820-8cb2de1431d7','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(118,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','7961fa09-8646-473e-83ad-fe67b761d9b0','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(119,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','a0cab9e1-0f33-4299-b2a4-7f274f8f2618','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(127,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','178b0179-c690-44e6-a9d9-9bcf0762b59a','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(128,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','4318fa3d-e4d2-48c2-b36b-0a7a777f6049','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(133,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','45270135-3439-4b5d-870a-fee6cec9cb8d','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(134,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','f8ed36bb-a7e1-45bd-a0cd-d1303057e62e','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(135,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','e50201f0-74e2-48ee-a00a-ecc4c8bd58f7','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(136,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','ef33e8bf-6664-4435-9c00-94cdc65d1687','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(137,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','52d48923-631c-4a1b-b56b-8d029b297c4a','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(138,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','b6a61b1b-6fcb-4800-96ab-bca02e0282f8','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(139,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','6d178d12-b32a-4c64-916f-cc2a20be687b','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(140,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','7c8f20ac-fd44-4d1a-b289-dc85911132ad','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(141,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','6f5c90f0-e14c-4994-9b63-23c592be4c4a','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(142,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','eb392815-00bd-4cb2-b865-0a983843cc3c','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(143,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','0b17c64d-82bf-4eeb-884f-3f0592b2b958','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(151,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','0192eea5-5bc1-43bb-aaa8-d42d898674c7','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(159,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','e2280c7f-9a49-4cd8-a41e-74458e61cbc5','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(166,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','8f35a585-f67c-4ec5-b10c-a439002b378e','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(167,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','79796133-a21d-4007-8d40-d1afca288fc4','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(168,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','a640e8c6-6280-4f5e-925d-0c0d396be09c','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(169,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','506d4a5e-3748-4b23-a56b-33fd46956a51','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(170,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','62690298-3f17-4395-81dd-0e8d55491883','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(171,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','409ff6bf-f28b-434a-8edc-1cea8b0b138a','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(187,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','15405954-6155-4e2d-af5d-9a3acde1d7b7','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(195,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','52f0c8f1-3836-42ae-acd8-dd2bccbea879','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(228,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','41ed3453-4875-4a53-8590-def590bbefca','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(260,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','c6010adf-b959-43bf-af21-5a5d10d7b0f6','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(262,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','7d9608d6-140e-4c50-9a1c-e788f4e88ccc','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(271,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','082acc1a-54d2-4b41-a1f2-884143efc9c1','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(287,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','b0b5b926-dc38-43b3-a137-420c07d8cc4f','40f5888b67c748df7efba008e7c2f9d2','#B00020'),(301,'Manu G','manuthecoder@protonmail.com','Admin','https://i.ibb.co/PrqtZZ3/2232ae71-edbe-4035-8c89-9cb9039fa06d.jpg','32659b2f-87ba-4fe2-b2c5-fd449b96672f','40f5888b67c748df7efba008e7c2f9d2','#B00020');
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-17 20:16:29
