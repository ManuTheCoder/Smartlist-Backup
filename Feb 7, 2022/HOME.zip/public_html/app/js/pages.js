function getHashPage() {
  var file =
    _pages[window.location.hash.replace("#", "")] || _user.preferences.homePage;
  if (document.querySelector(".bottom-nav-active")) {
    document
      .querySelectorAll(".bottom-nav-active")
      .forEach((d) => d.classList.remove("bottom-nav-active"));
  }
  if(document.querySelector(`#sidenav-drawer a[href='${window.location.hash}']`)) {
      document.querySelector(`#sidenav-drawer a[href='${window.location.hash}']`).click()
  }
  if (
    !window.location.hash ||
    window.location.hash.includes("dashboard") ||
    window.location.hash.includes("home")
  ) {
    document
      .getElementById("bottomNav.link1")
      .classList.add("bottom-nav-active");
  }
  if (window.location.hash.includes("finances")) {
    document
      .getElementById("bottomNav.link2")
      .classList.add("bottom-nav-active");
  }
  if (window.location.hash.includes("notifications")) {
    document
      .getElementById("bottomNav.link4")
      .classList.add("bottom-nav-active");
  }
  if (window.location.hash.includes("meal-planner")) {
    document
      .getElementById("bottomNav.link5")
      .classList.add("bottom-nav-active");
  }
  var app = document.getElementById("app");
  app.innerHTML = loader;
  fetch(file)
    .then((res) => (res.status == 404 ? res : res.text()))
    .then((res) => {
      if (res.status === 404) {
        app.innerHTML = `
			<div class="loader-container" style="margin-top: -64px">
				<div class="container center">
				<h4>Uh oh!</h4>
			    <p class="grey-text text-darken-2">We couldn't load the page you asked for. Try reloading this page if it might help</p>
				</div>
			</div>
			`;
      } else {
        app.innerHTML = res;
        function executeScriptElements(containerElement) {
          const scriptElements = containerElement.querySelectorAll("script");

          Array.from(scriptElements).forEach((scriptElement) => {
            const clonedElement = document.createElement("script");

            Array.from(scriptElement.attributes).forEach((attribute) => {
              clonedElement.setAttribute(attribute.name, attribute.value);
            });

            clonedElement.text = scriptElement.text;

            app.appendChild(clonedElement);
          });
        }
        executeScriptElements(document.getElementById("app"));
      }
    })
    .catch((err) => alert(err));
  return file;
}
window.addEventListener("hashchange", getHashPage);
window.addEventListener("load", getHashPage);
export { getHashPage };
