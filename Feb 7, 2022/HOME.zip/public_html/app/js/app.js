
window.onerror = (msg, line, url) => {
  if (!msg.content.includes("DataCloneError"))
    alert(`Error\n${msg}\nLine: ${line}\n${url}`);
};
const Ripple = {
    init: () => {
        const buttons = document.querySelectorAll('.material-ripple:not(.ripple-ready)')
        const stopEvents = ["pointerup", "mouseleave", "dragleave", "touchmove", "touchend", "touchcancel"];
        let id;

        function findFurthestPoint(clickPointX, elementWidth, offsetX, clickPointY, elementHeight, offsetY) {
            let x = clickPointX - offsetX > elementWidth / 2 ? 0 : elementWidth;
            let y = clickPointY - offsetY > elementHeight / 2 ? 0 : elementHeight;
            let d = Math.hypot(x - (clickPointX - offsetX), y - (clickPointY - offsetY));
            return d;
        }

        buttons.forEach(button => {
            button.classList.add('ripple-ready');
            button.addEventListener('pointerdown', e => {
                const rect = button.getBoundingClientRect()
                const radius = findFurthestPoint(e.clientX, button.offsetWidth, rect.left, e.clientY, button.offsetHeight, rect.top)

                id = "__" + (Math.random() + 1).toString(36).substring(7) + '-' + (Math.random() + 1).toString(36).substring(7);

                const circle = document.createElement('div')
                circle.classList.add('ripple')
                circle.id = id

                circle.style.left = `${e.clientX - rect.left - radius}px`
                circle.style.top = `${e.clientY - rect.top - radius}px`
                circle.style.width = circle.style.height = `${radius * 2}px`

                button.appendChild(circle)
            })

            stopEvents.forEach(event => {
                button.addEventListener(event, () => {
                    const ripple = button.querySelector('.ripple#' + id)
                    if (ripple) {
                        ripple.style.opacity = '0'
                        setTimeout(() => {
                            ripple.remove()
                        }, 600)
                    }
                })
            })
        });
    }
};

document.documentElement.addEventListener("DOMNodeInserted", () => Ripple.init(true));
window.addEventListener("load", Ripple.init);

function changeNavColor() {
	var nav = document.getElementById("nav");
	if (document.documentElement.scrollTop > 0 || document.body.scrollTop > 0) {
		nav.classList.add("active");
		changeThemeColor(`rgba(${_user.theme.tint}, 1)`);
	} else {
		nav.classList.remove("active");
		changeThemeColor("default");
	}
}
if (/\bCrOS\b/.test(navigator.userAgent)) {
	document.getElementById("nav").classList.add("transition-chromeOS");
}
window.addEventListener("scroll", changeNavColor);


/**
 * @description - Changes the theme color
 * @param {color} string - The theme color to set
 */
function changeThemeColor(color) {
  var tag = document.querySelector(`meta[name='theme-color']`);
  tag.setAttribute("content", color == "default" ? "#fff" : color);
}
const loader = `
<div class="loader-container"> 
<svg width="38" height="38" viewBox="0 0 38 38" xmlns="http://www.w3.org/2000/svg" stroke="#000" style="margin-top: -65px">
<g fill="none" fill-rule="evenodd">
<g transform="translate(1 1)" stroke-width="2">
<circle stroke-opacity=".1" cx="18" cy="18" r="18"/>
<path d="M36 18c0-9.94-8.06-18-18-18">
<animateTransform
attributeName="transform"
type="rotate"
from="0 18 18"
to="360 18 18"
dur=".8s"
repeatCount="indefinite"/>
</path>
</g>
</g>
</svg>
</div>
`;

document.getElementById("sidenav-trigger").addEventListener("click", () => {
  M.Sidenav.getInstance(document.getElementById("sidenav-drawer")).open();
});

window._pages = {
  "/home": _user.preferences.homePage,
  "/dashboard": "/app/pages/dashboard.php",
  "/house-profile": "/app/pages/house-profile.php",
  "/profile": "/app/pages/profile.php",
  "/add/list": "/app/pages/lists/quickAddList.php",
  "/rooms/kitchen": "/app/pages/rooms/view.php?room=kitchen",
  "/rooms/bedroom": "/app/pages/rooms/view.php?room=bedroom",
  "/rooms/bathroom": "/app/pages/rooms/view.php?room=bathroom",
  "/rooms/garage": "/app/pages/rooms/view.php?room=garage",
  "/rooms/family": "/app/pages/rooms/view.php?room=family",
  "/rooms/storage": "/app/pages/rooms/view.php?room=storage",
  "/rooms/dining": "/app/pages/rooms/view.php?room=dining",
  "/rooms/camping": "/app/pages/rooms/view.php?room=camping",
  "/rooms/laundry": "/app/pages/rooms/view.php?room=laundry",
  "/rooms/laundry": "/app/pages/rooms/view.php?room=laundry",
  "/recipes": "/app/pages/recipes.php",

  "/add/kitchen": "/app/rooms/quickaddRoom.php?room=kitchen",
  "/add/bedroom": "/app/rooms/quickaddRoom.php?room=bedroom",
  "/add/bathroom": "/app/rooms/quickaddRoom.php?room=bathroom",
  "/add/garage": "/app/rooms/quickaddRoom.php?room=garage",
  "/add/family": "/app/rooms/quickaddRoom.php?room=family",
  "/add/storage": "/app/rooms/quickaddRoom.php?room=storage",
  "/add/dining-room": "/app/rooms/quickaddRoom.php?room=dining_room",
  "/add/camping": "/app/rooms/quickaddRoom.php?room=camping",
  "/add/laundry": "/app/rooms/quickaddRoom.php?room=laundry",

  "/add/room": "/app/rooms/custom_room/add_room.php",
  "/add/shopping-list": "/app/pages/grocerylist/quickadd.php",
  "/add/reminder": "/app/pages/todo/quickadd.php",

  "/add/subscription": "/app/pages/finance/subscription_quickadd.php",

  "/my-finances/set-plan": "/app/pages/finance/set-goal.php",
  "/my-finances": "/app/pages/finance/index.php",
  "/my-finances/payments": "/app/pages/finance/payments.php",
  "/my-finances/insights": "/app/pages/finance/insights.php",
  "/my-finances/lessons": "/app/pages/finance/lessons.php",
  "/my-finances/calculators": "/app/pages/finance/calculators.php",
  "/notifications": "/app/pages/notifications.php",

  "/notes": "/app/pages/notes/index.php",
  "/starred": "/app/rooms/starred-items.php",
  "/maintenance": "/app/rooms/maintenance.php?card",
  "/trash": "/app/rooms/trash/index.php",
  "/settings": "/app/pages/settings/index.php",
  "/maintenance": "/app/pages/maintenance.php?card"
};

window.addEventListener("load", () => {
  document.getElementById("accountDropdown.image").src = _user.image;
  document.getElementById("profileImage").style.animation = 'scale .2s forwards'
  document.getElementById("profileImage").innerHTML = `<img src="${_user.image}" class="circle grey lighten-4" style="width: 40px;height:40px" loading="lazy">`;
  document.getElementById("accountDropdown.name").textContent =
    _user.name;
  document.getElementById("accountDropdown.email").textContent =
    _user.email;


});


window.addEventListener("load", () => {
  document.getElementById("add.finance.form").addEventListener("submit", (event) => {
    event.preventDefault();
    
    fetch("https://smartlist.ga/app/pages/finance/addFinance.php?"+new URLSearchParams({
      n: document.getElementById("addFinanceSpent").value,
      label: document.getElementById('add.finance.form.label').value,
      date: moment().format('M/D/Y')
    })).then(res => {window.dispatchEvent(new Event("getHashPage"));M.toast({text: "Created expense!"});M.Modal.getInstance(document.getElementById('add.finance')).close();document.getElementById('add.finance.form').reset})
  });
})

// FAB
var prevScrollpos = window.pageYOffset;
window.addEventListener("scroll", () => {
  var currentScrollPos = window.pageYOffset;
  if(window.pageYOffset == 0) {
    document.querySelector(".bottom-nav").classList.remove("bottom-nav-hide");  
    // document.querySelector("#fab").parentElement.classList.remove("fab-bottom");
  }
  else {
    document.querySelector(".bottom-nav").classList.add("bottom-nav-hide");
    // document.querySelector("#fab").parentElement.classList.add("fab-bottom");
  }
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("fab").classList.remove("fab-concise");
  } else {
    document.getElementById("fab").classList.add("fab-concise");
  }

  prevScrollpos = currentScrollPos;
});

Mousetrap.bind(["command+k", "ctrl+k"], function (e) {
  document
    .querySelectorAll(".modal")
    .forEach((d) => M.Modal.getInstance(d).close());
  M.Modal.getInstance(document.getElementById("search")).open();
  document.querySelector("#search input").focus();
  return false;
});
Mousetrap.bind(["command+/", "ctrl+/"], function (e) {
  document
    .querySelectorAll(".modal")
    .forEach((d) => M.Modal.getInstance(d).close());
  M.Modal.getInstance(document.getElementById("shortcuts")).open();
  return false;
});
Mousetrap.bind(["command+g", "ctrl+g"], function (e) {
  document
    .querySelectorAll(".modal")
    .forEach((d) => M.Modal.getInstance(d).close());
  M.Modal.getInstance(document.getElementById("add.shoppingList")).open();
  setTimeout(() =>
             document.getElementById("add.shoppingList.form.name").focus()
            );
  return false;
});
Mousetrap.bind(["command+s", "ctrl+s"], function (e) {
  document
    .querySelectorAll(".modal")
    .forEach((d) => M.Modal.getInstance(d).close());

  M.Modal.getInstance(document.getElementById("addItem")).open();
  return false;
});
Mousetrap.bind(["command+l", "ctrl+l"], function (e) {
  document
    .querySelectorAll(".modal")
    .forEach((d) => M.Modal.getInstance(d).close());

  M.Modal.getInstance(document.getElementById("add.reminder")).open();
  setTimeout(() => document.getElementById("add.reminder.form.name").focus());
  return false;
});

Mousetrap.bind(["command+m", "ctrl+m"], function (e) {
  document
    .querySelectorAll(".modal")
    .forEach((d) => M.Modal.getInstance(d).close());

  M.Modal.getInstance(document.getElementById("add.note")).open();
  setTimeout(() => document.getElementById("add.note.form.name").focus());
  return false;
});
Mousetrap.bind(["command+b", "ctrl+b"], function (e) {
  document
    .querySelectorAll(".modal")
    .forEach((d) => M.Modal.getInstance(d).close());

  M.Modal.getInstance(document.getElementById("add.finance")).open();
  document.getElementById("addFinanceSpent").focus();
  return false;
});

document.querySelector("#search input").addEventListener("input", () => {
  if (document.querySelector("#search input").value !== "") {
    document.querySelector("#searchResults").classList.add("active");
  } else {
    document.querySelector("#searchResults").classList.remove("active");
  }
});

function debounce(callback, wait) {
  let timeout;
  return (...args) => {
    clearTimeout(timeout);
    timeout = setTimeout(function () { callback.apply(this, args); }, wait);
  };
}
document.querySelector("#search input").addEventListener('keyup', debounce( () => {
  fetch("/app/pages/search.php?q="+encodeURIComponent(document.querySelector("#search input").value))
    .then(res => res.json()) 
    .then(res => {
    document.getElementById("searchResults").innerHTML = `${res.length==0?`<div class="center" style="padding:10px;">No results found.</div>`:""}${res.map(item => {
      return `<a href="#/rooms/${item.room.toLowerCase()}" class="collection-item material-ripple black-text text-darken-2"> <i class="material-icons blue lighten-5">view_in_ar</i> ${item.name}<br><span class="grey-text text-darken-3">${item.room}</span> </a>`
    }).join("")}`
  })
  // further keyup events reset the timer, as expected
}, 300))

document.getElementById("bottomNav.link3").addEventListener("click", () => {
  setTimeout(()=>document.querySelector("#search input").focus(), 100)
})

/**
 * @description - Handles a form
 * @param {*} event - The form submit event
 */
function sendData(event, callback = () => {}) {
  event.preventDefault();
  const _http = new XMLHttpRequest();
  // Bind the FormData object and the form element
  const data = new FormData(event.target);

  // Define what happens on successful data submission
  return new Promise((resolve, reject) => {
    _http.addEventListener("load", function (event) {
      callback(event.target.responseText);
      resolve(event.target.responseText);
    });
    // Define what happens in case of error
    _http.addEventListener("error", function (event) {
      alert("Oops! Something went wrong.");
    });

    // Set up our request
    _http.open(
      event.target.method ? event.target.method : "POST",
      event.target.action
    );

    // The data sent is what the user provided in the form
    _http.send(data);
  });
}
function bmNumber(e) {
  if (e !== "backspace") {
    document.getElementById("addFinanceSpent").value += e;
  } else {
    document.getElementById("addFinanceSpent").value = document
      .getElementById("addFinanceSpent")
      .value.toString()
      .slice(0, -1);
  }
}
if (window.innerWidth < 992) {
  document.getElementById("addFinanceSpent").readOnly = true;
}

// Swipe

var mc = new Hammer(document.getElementById('addItem'));
mc.add( new Hammer.Pan({ direction: Hammer.DIRECTION_ALL, threshold: 0 }) );
mc.on("pandown", handleDrag);
function handleDrag(ev) {
  var el = document.getElementById('addItem');
  var posY = -ev.deltaY;

  /* console.log(el.offsetTop, window.innerHeight/1.2); */
  if(el.offsetTop >= window.innerHeight/1.1 || ev.velocityY > 4) {
   M.Modal.getInstance(el).close()
  }
  else {
    el.style.bottom = posY + "px";
  }

  document.body.addEventListener((/Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent) ? "touchend": "mouseup"), ()=>{
    el.style.transition="bottom .2s";
    el.style.bottom="0px";
    setTimeout(()=>el.style.transition="", 200);
  });
};


window.addEventListener("load", (e) => {
  document.title = `${_user.profile.home.name} • Smartlist`;
  document.getElementById(
    "houseName"
  ).textContent = `${_user.profile.home.name}`;
});

document
  .getElementById("add.reminder.trigger")
  .addEventListener("click", () =>
                    setTimeout(() => document.getElementById("add.reminder.form.name").focus())
                   );
document
  .getElementById("add.note.trigger")
  .addEventListener("click", () =>
                    setTimeout(() => document.getElementById("add.note.form.name").focus())
                   );
document
  .getElementById("add.shoppingList.trigger")
  .addEventListener("click", () =>
                    setTimeout(() =>
                               document.getElementById("add.shoppingList.form.name").focus()
                              )
                   );
document
  .getElementById("add.list.trigger")
  .addEventListener("click", () =>
                    setTimeout(() => document.getElementById("add.list.form.name").focus())
                   );
setInterval(
  () =>
  document.querySelectorAll("a, img").forEach((d) => {
    if (
      !d.getAttribute("draggable") ||
      d.getAttribute("draggable") !== "false"
    )
      d.setAttribute("draggable", "false");
  }),
  300
);
M.Sidenav.init(document.getElementById("item_sidenav"), {
    edge: "right",
    onOpenStart: () => changeThemeColor(window.innerWidth > 992 ? "#7a7a7a":"#fff"),
    onCloseStart: () => changeThemeColor(window.pageYOffset !== 0 ? `rgba(${_user.theme.tint}, 1)`:"default"),
});

function item(el) {
  var sidenav = document.getElementById("item_sidenav");
  M.Sidenav.getInstance(sidenav).open();
  var data = {
    star: el.getAttribute("data-star"),
    room: el.getAttribute("data-room"),
    id: el.getAttribute("data-id"),
    categories: el.getAttribute("data-categories").split(","),
    lastUpdated: el.getAttribute("data-lastUpdated"),
    sync: el.getAttribute("data-sync"),
    name: el.querySelectorAll("td")[0],
    qty: el.querySelectorAll("td")[1],
  };
  sidenav.innerHTML = `
<nav style="border-bottom: 1px solid rgba(200, 200, 200, .2);">
<ul>
<li>
<a 
id="item_back"
draggable="false"
onkeyup="if(event.keyCode===27)this.click()"
onkeydown="if(event.keyCode===27)this.click()"
class="sidenav-close navbar-button waves-center material-ripple" onclick="M.Sidenav.getInstance(document.getElementById('item_sidenav')).close()"
href="javascript:void(0)" style="vertical-align: middle"><i class="material-icons grey-text text-darken-3">chevron_left</i></a>
</li>
</ul>


<ul class="right">
<li>
<a 
draggable="false"
data-target="edit_modal"
onclick="setTimeout(()=>document.getElementById('edit_name').focus(),20)"
class="modal-trigger navbar-button waves-center material-ripple"
href="javascript:void(0)" style="margin-right:3px;vertical-align: middle"><i class="material-icons grey-text text-darken-3">edit</i></a>
</li>
<li>
<a 
draggable="false"
data-target="delete_modal"
onclick="setTimeout(()=>document.getElementById('delete_ok').focus(),20)"
class="navbar-button modal-trigger waves-center"
href="javascript:void(0)" style="margin:0 3px;vertical-align: middle"><i class="material-icons grey-text text-darken-3">delete</i></a>
</li>
<li>
<a 
draggable="false"
id="item_star"
class="navbar-button waves-center material-ripple"
href="javascript:void(0)" style="margin:0 3px;vertical-align: middle"><i class="material-icons grey-text text-darken-3">${
  data.star === "1" ? "star" : "star_outline"
}</i></a>
</li>
<li>
<a 
draggable="false"
id="more_trigger"
data-target="item_popup_moreActions"
class="navbar-button waves-center material-ripple"
href="javascript:void(0)" style="margin-left:0;margin-right:0;vertical-align: middle"><i class="material-icons grey-text text-darken-3">more_vert</i></a>
</li>
</ul>
</nav>
<ul id="item_popup_moreActions" class="dropdown-content">
<li><a href="javascript:void(0)" data-target="modal_info" class="modal-trigger dropdown-no-padding"><i class="material-icons left">info</i>View details</a></li>
<li><a id="nav_share" href="javascript:void(0)" class="dropdown-no-padding"><i class="material-icons left">share</i>Share</a></li>
<li><a id="nav_whatsapp"  href=" https://wa.me/?text=${encodeURIComponent(
    data.name.innerText
  )}" class="dropdown-no-padding"><i class="material-icons left">chat</i>WhatsApp</a></li>
<li><a id="nav_recipe" href="javascript:void(0)" class="dropdown-no-padding"><i class="material-icons left">auto_awesome</i>Find recipes</a></li>
<li><a id="nav_collab" href="javascript:void(0)" class="dropdown-no-padding"><i class="material-icons left">person_add</i>Invite collaborators</a></li>
<li><a id="nav_shoppingList" href="javascript:void(0)" class="dropdown-no-padding"><i class="material-icons left">receipt_long</i>Add to shopping list</a></li>
<li><a id="nav_moveTo" href="javascript:void(0)" class="dropdown-no-padding"><i class="material-icons left">bolt</i>Move to</a></li>
<li><a id="nav_qr" href="javascript:void(0)" class="dropdown-no-padding"><i class="material-icons left">qr_code_scanner</i>Create QR code</a></li>
</ul>
<div class="modal modal-rounded modal-center" id="modal_info">
<div class="modal-content">
<h5>Info</h5>
<p>ID:<br><span class="grey-text text-darken-2">${data.id}</span></p>
<p>Last updated:<br><span class="grey-text text-darken-2">${
  data.lastUpdated
}</span></p>
<p>Sync:<br><span class="grey-text text-darken-2">${data.sync == "1"}</span></p>
<p>Starred:<br><span class="grey-text text-darken-2">${
  data.star == "1"
}</span></p>
<p>Name:<br><span class="grey-text text-darken-2">${
  data.name.innerText
}</span></p>
<p>Quantity:<br><span class="grey-text text-darken-2">${
  data.qty.innerText
}</span></p>
</div>
</div>
<div class="container" style="justify-content: center;display: flex;align-items: center;flex-direction:column;height:100vh">
<div class="container">
<h1><b>${data.name.innerText}</b></h1>
<h4>${data.qty.innerText}</h4>
<div class="mt-2">
${
  data.categories[0].trim() == ""
    ? ""
  : data.categories
    .map((category) => {
    return `<div class="chip">${category}</div>`;
  })
    .join("")
}
</div>
</div>
</div>
<div id="edit_modal" class="modal-rounded modal modal-center">
<div class="modal-content">
<h5>Edit item</h5>
<form id="edit_form" method="POST" action="${data.room == "custom_room" ? '/app/rooms/custom_room/custom_item_edit.php' : '/app/rooms/editItem.php'}">
<div class="input-field col s6 input-border">
<input name="name" id="edit_name" type="text" class="validate" autocomplete="off">
<label for="edit_name" style="margin-left:0!important">Item Name</label>
</div>
<div class="input-field col s6 input-border">
<input name="qty" id="edit_qty" type="text" class="validate" autocomplete="off">
<label for="edit_qty" style="margin-left:0!important">Quantity</label>
</div>
<div class="input-field col s6 input-border">
<input name="price" id="edit_categories" type="text" class="validate" autocomplete="off">
<label for="edit_categories" style="margin-left:0!important">Categories</label>
</div>
<p>
<label>
<input ${
  data.qty.innerText.toLowerCase().includes("in stock") ? "checked" : ""
} type="checkbox" oninput="if(this.checked===true){document.getElementById('edit_qty').value=document.getElementById('edit_qty').value+' (In stock)'} else {document.getElementById('edit_qty').value=document.getElementById('edit_qty').value.replace(' (In stock)','')}" />
<span>In stock?</span>
</label>
<input type="hidden" name="id" id="edit_item_id" value='${data.id}'>
<input type="hidden" name="date" id="date1" value='${moment().format(
    "MMMM D [at] h:mma"
  )}'>
</p>
<div class="right-align mt-5">
<button type="button" class="btn-rounded modal-close btn z-depth-0 transparent black-text">Cancel</button>
<button class="btn-rounded modal-close sidenav-close btn z-depth-0 transparent black-text">Update</button>
</div>
</form>
</div>
</div>
<div id="qr_modal" class="modal-rounded modal modal-center"></div>
<div id="delete_modal" class="modal-rounded modal modal-center">
<div class="modal-content">
<h5>Move item to trash?</h5>
<p class="grey-text text-darken-2">You can recover deleted items</p>
<div class="right-align mt-5">
<button class="btn-rounded modal-close btn z-depth-0 transparent black-text">Cancel</button>
<button id="delete_ok" onclick="" class="btn-rounded btn z-depth-0 transparent red-text text-darken-3">Delete</button>
</div>
</div>
</div>
`;
  window.ev1 = document.getElementById("item_star").addEventListener("click", (ev) => {
    fetch(
      data.room == "custom_room"
      ? "/app/rooms/custom_room/star.php?id=" + data.id
      : "/app/rooms/starItem.php?id=" + data.id
    );
    let s = document.getElementById("item_star");
    el.style.borderLeft = s.innerText !== "star" ? "3px solid #f57f17" : "none";
    el.setAttribute("data-star", (data.star == 0 ? 1 : 0))
    s.querySelector("i").innerHTML =
      s.innerText == "star" ? "star_outline" : "star";
  });
  window.ev2 = document.getElementById("delete_ok").addEventListener("click", (ev) => {
    document.getElementById(
      "delete_ok"
    ).innerHTML = `<svg width="15" height="15" viewBox="0 0 38 38" xmlns="http://www.w3.org/2000/svg" stroke="#000"> <g fill="none" fill-rule="evenodd"> <g transform="translate(1 1)" stroke-width="2"> <circle stroke-opacity=".1" cx="18" cy="18" r="18"/> <path d="M36 18c0-9.94-8.06-18-18-18"> <animateTransform attributeName="transform" type="rotate" from="0 18 18" to="360 18 18" dur=".8s" repeatCount="indefinite"/> </path> </g> </g> </svg>`;

    fetch(
      data.room == "custom_room"
      ? "/app/rooms/custom_room/deleteItem.php?id=" + data.id
      : "/app/rooms/deleteItem.php?id=" + data.id
    ).then((res) => {
      el.remove();
      M.Sidenav.getInstance(document.getElementById("item_sidenav")).close();
      M.Modal.getInstance(document.getElementById("delete_modal")).close();
      M.toast({ text: "Item moved to trash" });
    });
  });
  window.ev3 = document.getElementById("edit_form").addEventListener("submit", (event) =>
                                                        sendData(event).then((res) => {
    M.toast({ text: "Updated item!" });
    data.name.innerHTML = document.getElementById("edit_name").value;
    data.qty.innerHTML = document.getElementById("edit_qty").value;
  })
                                                       );
  document.getElementById("nav_share").addEventListener("click", () => {
    navigator.share(
      `I currently have ${data.qty.innerText} ${data.name.innerText} in my ${data.room}`
    );
  });
  window.ev4 = document.getElementById("nav_recipe").addEventListener("click", () => {
    window.open(
      `https://google.com/search?q=${encodeURI(
        "Recipes with " + data.name.innerText
      )}`
    );
  });
  window.ev5 = document.getElementById("nav_shoppingList").addEventListener("click", () => {
    fetch("./rooms/shopping_add.php?name=" + data.name.innerText).then((res) =>
                                                                       M.toast({ text: "Added to shopping list" })
                                                                      );
  });
  window.ev6 =document.getElementById("nav_qr").addEventListener("click", () => {
    let qr = document.getElementById("qr_modal");
    let url = `https://api.qrserver.com/v1/create-qr-code/?size=800x800&data=${encodeURI(
      `I currently have ${data.qty.innerText} ${data.name.innerText} in my ${data.room})`
    )}`;
    qr.innerHTML = `
<div class="modal-content">
<img src="${url}" style="width:100%;" onload="M.Modal.getInstance(document.getElementById('qr_modal')).open()">
<div class="center">
<a download='download' href="${url}" class="btn btn-rounded bg-theme black-text z-depth-0 mt-4">Download PNG</a>
</div>
</div>
`;
  });
  document.getElementById("edit_name").value = data.name.innerText;
  document.getElementById("edit_qty").value = data.qty.innerText;
  document.getElementById("edit_categories").value = data.categories.join(", ");
  setTimeout(() => document.getElementById("item_back").focus());
  M.updateTextFields();
  M.Dropdown.init(document.getElementById("more_trigger"), {
    constrainWidth: false,
  });
  M.Modal.init(
    document.querySelectorAll(
      "#qr_modal, #modal_info, #edit_modal, #delete_modal"
    ),
    {
      opacity: (window.innerWidth > 992 ? 0.6 : 0.3),
      inDuration: 100,
      onCloseStart: () => changeThemeColor(window.innerWidth > 992 ? "#7a7a7a" : "#fff" ),
      onOpenStart: () => changeThemeColor(window.innerWidth > 992 ? "#7a7a7a" : "#aaa" ),
      outDuration: 100,
    }
  );
}

document.getElementById("add.note.form").addEventListener("submit", (event) => sendData(event).then((res) => {
  M.toast({ text: "Created note!" });
  document.getElementById('add.note.form').reset();
  window.dispatchEvent(new Event("getHashPage"));
  alert(res)
}))

document.getElementById("add.shoppingList.form").addEventListener("submit", (event) => sendData(event).then((res) => {
  window.dispatchEvent(new Event("getHashPage"));
  document.getElementById('add.shoppingList.form').reset();
  M.toast({text: res});
}))
document.getElementById("add.reminder.form").addEventListener("submit", (event) => sendData(event).then((res) => {
  window.dispatchEvent(new Event("getHashPage"));
  document.getElementById('add.shoppingList.form').reset();
  M.toast({text: res});
}))
document.getElementById("add.list.form").addEventListener("submit", (event) => sendData(event).then((res) => {
  window.dispatchEvent(new Event("getHashPage"));
  document.getElementById('add.list.form').reset();
  M.toast({text: res});
}))
function sortTable(n, table, dir = "asc") {
  var rows,
      switching,
      i,
      x,
      y,
      shouldSwitch,
      switchcount = 0;
  switching = true;
  /*Make a loop that will continue until
   no switching has been done:*/
  while (switching) {
    // //start by saying: no switching is done:
    switching = false;
    rows = table.rows;
    /*Loop through all table rows (except the
      first, which contains table headers):*/
    for (i = 1; i < rows.length - 1; i++) {
      //start by saying there should be no switching:
      shouldSwitch = false;
      /*Get the two elements you want to compare,
         one from current row and one from the next:*/
      x = rows[i].getElementsByTagName("TD")[n];
      y = rows[i + 1].getElementsByTagName("TD")[n];
      //check if the two rows should switch place:
      if (dir == "asc") {
        if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
          //if so, mark as a switch and break the loop:
          shouldSwitch = true;
          break;
        }
      } else if (dir == "desc") {
        if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
          shouldSwitch = true;
          break;
        }
      }
    }
    /*If a switch has been marked, make the switch
        and mark that a switch has been done:*/
    if (shouldSwitch) {
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
      switchcount++;
    } else {
      if (switchcount == 0 && dir == "asc") {
        dir = "desc";
        switching = true;
      }
    }
  }
}

function viewNote(id) {
    function getCookie(name) {
        const value = `; ${document.cookie}`;
        const parts = value.split(`; ${name}=`);
        if (parts.length === 2) return parts.pop().split(';').shift();
    }
  var nm = document.getElementById('note.viewModal');
  nm.style.transform = "none!important";
  nm.style.top = "0 !important";
  nm.style.left = "0 !important";
  
  M.Modal.getInstance(nm).open();
  nm.innerHTML = "";
  fetch('https://api.smartlist.ga/v2/notes/fetch/', {
        method: "POST",
        body: "token="+getCookie('UserToken')+"&id="+id,
        headers: { "Content-Type": "application/x-www-form-urlencoded" }
    })
    .then(res => res.json())
    .then(res => {
    nm.innerHTML = `
<div class="container" style="margin: 0!important;padding: 55px!important;margin-top: 55px!important">
<div style="position:fixed;bottom: 0;right:0;padding: 40px;" id="saveStatus">All changes are up-to-date</div>
<div style="position:fixed;top: 0;right:0;padding: 40px;">
<a href="javascript:void(0)" class="btn material-ripple btn-round btn-floating modal-close z-depth-0 transparent mx-2"><i class="black-text material-icons">delete</i></a>
<a href="javascript:void(0)" class="btn material-ripple btn-round btn-floating modal-close z-depth-0 transparent mx-2"><i class="black-text material-icons">close</i></a>
</div>
<div class="fadeImage" style="z-index:-1;background-image: url(${res.data.banner == "" ? "https://i.ibb.co/8NW7tNg/blurry-gradient-haikei.png":res.data.banner});"></div>
<input class="browser-default truncate mb-4 transparent" style="width:100vw;text-overflow:ellipsis;font-size: 70px;font-family: 'Outfit', sans-serif;padding: 10px 0;border:0;outline:0;text-decoration:underline" value="${res.data.title}" id="title">
<div id="editorjs" class="editor"></div>
</div>
`;
    const _noteData = res.data.content.blocks

    const editor = new EditorJS({
      data: {
        blocks: _noteData
      },
      onReady: () => {
        new DragDrop(editor);
      },
      placeholder: "Compose an epic...",
      minHeight: 0,
      holder: 'editorjs',
      onChange: function(d, e) {
        document.getElementById('saveStatus').innerHTML = `<svg width="25" height="25" viewBox="0 0 38 38" xmlns="http://www.w3.org/2000/svg" stroke="#000"> <g fill="none" fill-rule="evenodd"> <g transform="translate(1 1)" stroke-width="2"> <circle stroke-opacity=".1" cx="18" cy="18" r="18"/> <path d="M36 18c0-9.94-8.06-18-18-18"> <animateTransform attributeName="transform" type="rotate" from="0 18 18" to="360 18 18" dur=".8s" repeatCount="indefinite"/> </path> </g> </g> </svg>`;

        editor.save().then((outputData) => {
          fetch('https://api.smartlist.ga/v2/notes/save/', {
                method: "POST",
                body: `token=${getCookie('UserToken')}&id=${id}&content=${encodeURIComponent(JSON.stringify(outputData))}&title=${encodeURIComponent(document.getElementById("title").value)}`,
                headers: { "Content-Type": "application/x-www-form-urlencoded" }
            })
            .then(res => res.json())
            .then(res => {
            document.getElementById('saveStatus').innerHTML = res.data
          })
        }).catch((error) => {

          document.getElementById('saveStatus').innerHTML = `<div class="modal-close red darken-4 white-text" style="display: inline-block!important;padding: 15px 30px;border-radius: 9999px">Error saving changes!</div>`
          console.log('Saving failed: ', error);
        });
      },
      tools: { 
        checklist: {
          class: Checklist,
          inlineToolbar: true,
        },
        paragraph: {
          class: Paragraph,
          inlineToolbar: true,
        },
        list: {
          class: List,
          inlineToolbar: true,
        },
        inlineCode: {
          class: InlineCode,
          shortcut: 'CMD+SHIFT+M',
        },
        warning: Warning,
        Marker: Marker,
        delimiter: Delimiter,
        image: SimpleImage,
        quote: Quote,
        code: CodeTool,
        alert: Alert,
        underline: Underline,
        table: Table,
        paragraph: {
          class: Paragraph,
          inlineToolbar: true,
        },

        header: {
          class: Header, 
          config: {
            placeholder: 'Enter a header',
            levels: [2, 3, 4],
            defaultLevel: 3
          },

          inlineToolbar: ['link'] 
        }, 
      }
    });
  })
}
function addTask(name, desc) {
  M.Modal.getInstance(document.getElementById("add.reminder")).open();
  document.getElementById("add.reminder.form.name").value = name;
}
document.querySelectorAll("#sidenav-drawer li a:not(.subheader)").forEach(el => {
  el.addEventListener("click", ()=> {
    if(document.querySelector(".sidenav-active")) document.querySelectorAll(".sidenav-active").forEach(d => d.classList.remove('sidenav-active'));
    el.classList.add("sidenav-active")
  })
})