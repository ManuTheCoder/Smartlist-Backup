window.addEventListener("load", () => {
M.Modal.init(document.querySelectorAll(".modal"), {
	outDuration: 200,
	inDuration: 200,
	onOpenStart: () => changeThemeColor("#808080"),
	onCloseStart: () => changeThemeColor("default"),
});
M.Modal.init(document.getElementById("viewAccount"), {
	opacity: (window.innerWidth>992 ? 0: .5),
	onOpenStart: () => changeThemeColor((window.innerWidth > 992 ? "#fff" :  "#808080")),
	onCloseStart: () => changeThemeColor("default"),
});

M.Modal.init(document.getElementById("search"), {
	onOpenStart: () => changeThemeColor((window.innerWidth > 992 ? "#808080": "#fff")),
	onCloseStart: () =>
		{changeThemeColor("default");document.querySelector("#searchResults").classList.remove("active")},
});

M.Dropdown.init(document.querySelector('.dropdown-trigger'), {
	constrainWidth: false,
    container: document.body
})

M.Datepicker.init(document.querySelectorAll(".datepicker"), {
	container: document.body,
	minDate: new Date(),
	showDaysInNextAndPreviousMonths: true,
	showClearBtn: true,
	autoClose: true,
})

M.Sidenav.init(document.querySelectorAll(".sidenav"), {
	// onOpenStart: () => changeThemeColor("#808080"),
	onCloseStart: () => changeThemeColor("default"),
	inDuration: 200,
});
M.FormSelect.init(document.querySelectorAll("select"), {
	
});
});