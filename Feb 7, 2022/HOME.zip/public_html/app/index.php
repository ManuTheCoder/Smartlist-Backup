<?php
ini_set("display_errors", 1);
require 'cred.php';
require 'encrypt.php';

if(!isset($_COOKIE['UserToken'])) {
    header('Location: /app/login/');
    exit();
}

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.smartlist.ga/v2/account/info/',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => 30,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/x-www-form-urlencoded'
  ),
));
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($curl, CURLOPT_POSTFIELDS, 'token='.$_COOKIE['UserToken']);

$_USER = json_decode(curl_exec($curl));
$_USER->data->preferences = new stdClass();
$_USER->data->preferences->homePage = "/app/dashboard.php";
unset($_USER->data->id);
curl_close($curl);
?>

<!DOCTYPE html>
<html style="--user-theme-nav: <?=implode(',', $_USER->data->theme->tint)?>; --user-theme-regular: <?=implode(',', $_USER->data->theme->original)?>;">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="theme-color" content="#fff">
    <script src="https://cdn.jsdelivr.net/npm/lazyload@2.0.0-rc.2/lazyload.js"></script>
    <title>My Home • Smartlist</title>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script src="https://unpkg.com/masonry-layout@4/dist/masonry.pkgd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/sha256.min.js" integrity="sha512-fv28nWHTcWfoN3KBd2fs+YWsirQ+L0b/iIRS7HcNDPSAwxy6oSjRrYjQ+OtJoJz0wUKsVcPYgwcZzK04KfHD0A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js" integrity="sha512-E8QSvWZ0eCLGk4km3hxSsNmGWbLtSCSUcewDQPQWZF6pEU8GlT8a5fF32wOl1i8ftdMhssTrF/OhyGWwonTcXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js" integrity="sha512-qTXRIMyZIFb8iQcfjXWCO8+M5Tbc38Qi5WzdPOYZHIlZpzBHG3L3by84BBBOiRGiEb7KKtAOAs5qYdUiZiQNNQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mousetrap/1.6.5/mousetrap.min.js" integrity="sha512-+Jg3Ynmj9hse704K48H6rBBI3jdNBjReRGBCxUWFfOz3yVurnJFWtAWssDAsGtzWYw89xFWPxShuj2T6E9EOpg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://hammerjs.github.io/dist/hammer.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Material+Icons|Material+Icons+Outlined|Material+Icons+Two+Tone|Material+Icons+Round|Material+Icons+Sharp" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@materializecss/materialize@1.1.0-alpha/dist/css/materialize.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Outfit">
    <script src="https://cdn.jsdelivr.net/npm/@materializecss/materialize@1.1.0-alpha/dist/js/materialize.min.js"></script>

    <link rel="stylesheet" href="./css/app.css">
    <link rel="stylesheet" href="./css/finances.css">
    <link rel="stylesheet" href="./css/utilities.css">
  </head>
  <body>
    <nav id="nav">
      <ul>
        <li class="hide-on-med-and-down"><a></a></li>
        <li>
          <a 
             class="navbar-button material-ripple waves-center hide-on-large-only"
             id="sidenav-trigger"
             href="javascript:void(0)"><i class="material-icons">menu</i></a>
        </li>
        <li>
          <a href="#/profile/home" id="houseName" class="truncate brand-logo">Home</a>
        </li>
      </ul>
      <ul class="right">
        <li>
          <a 
             class="navbar-button material-ripple waves-center hide-on-small-only"
             href="#/notifications"><i class="material-icons">notifications</i></a>
        </li>
        <li class="hide-on-small-only">
          <a 
             class="navbar-button material-ripple tooltip waves-center modal-trigger" style="margin-right:6px!important"
             href="javascript:void(0)" data-target="search"><i class="material-icons">search</i></a>
        </li>
        <li class="hide-on-small-only">
          <a 
             class="navbar-button material-ripple tooltip waves-center dropdown-trigger" style="margin-left:0!important"
             href="javascript:void(0)" id="appTrigger" data-target="apps"><i class="material-icons">apps</i></a>
        </li>

        <li>
          <a 
             class="navbar-button material-ripple waves-center material-ripple@light modal-trigger"
             href="javascript:void(0)"
             data-target="viewAccount" id="profileImage">
            <svg width="34" height="34" viewBox="0 0 38 38" xmlns="http://www.w3.org/2000/svg" stroke="#000"> <g fill="none" fill-rule="evenodd"> <g transform="translate(1 1)" stroke-width="2"> <circle stroke-opacity=".1" cx="18" cy="18" r="18"/> <path d="M36 18c0-9.94-8.06-18-18-18"> <animateTransform attributeName="transform" type="rotate" from="0 18 18" to="360 18 18" dur=".6s" repeatCount="indefinite"/> </path> </g> </g> </svg>
          </a>
        </li>
      </ul>
    </nav>

    <div class="bottom-nav hide-on-large-only" style="border-top: 1px solid #eee">
      <a id="bottomNav.link1"  href="#/dashboard" class="material-ripple"><i class="material-icons-outlined">dashboard</i><span class="truncate">Home</span></a>
      <a id="bottomNav.link2" href="#/my-finances" class="material-ripple"><i class="material-icons-outlined">payments</i><span class="truncate">Finances</span></a>
      <a id="bottomNav.link3" data-target="search" href="javascript:void(0)" class="modal-trigger material-ripple"><i class="material-icons-outlined">search</i><span class="truncate">Search</span></a>
      <a id="bottomNav.link4"  href="#/notifications" class="material-ripple"><i class="material-icons-outlined">notifications</i><span class="truncate">Recent</span></a>
      <a id="bottomNav.link5" href="#/meal-planner" class="material-ripple"><i class="material-icons-outlined">restaurant_menu</i><span class="truncate">Meals</span></a>
    </div>
    <ul id="apps" class="dropdown-content white" style="min-width: 300px;max-width: 100vw;">
      <li class=""><a href="//collaborate.smartlist.ga" target="_blank" class="material-ripple">
        Smartlist Collaborate<br>
        <span class="grey-text text-darken-2">Plan your events in real-time</span>
        </a></li>
      <li class=""><a href="//collaborate.smartlist.ga" target="_blank" class="material-ripple">
        Smartlist Parking<br>
        <span class="grey-text text-darken-2">Track where you parked your car</span>
        </a></li>
      <li class=""><a href="#/recipes" class="material-ripple">
        Recipes<br>
        <span class="grey-text text-darken-2">Generate recipes with ease</span>
        </a></li>
      <li class=""><a href="/app/user/shopping-assistant" target="_blank" class="material-ripple">
        Assistant<br>
        <span class="grey-text text-darken-2">In-store shopping assistant</span>
        </a></li>
    </ul>

    <div class="modal modal-border-dark modal-rounded" id="viewAccount">
      <div class="modal-content center">
        <img src="" class="circle w-full gray" loading="lazy" id="accountDropdown.image" style="max-width:100px;">
        <h5 class="mt-5" id="accountDropdown.name"></h5	>
        <h6 class="mt-3 gray-text text-darken-1" id="accountDropdown.email"></h6>
        <div clsas="flex" style="gap:10px;width: 100%">
            <a href="#/settings" style="width:50%" class="btn btn-rounded blue-grey z-depth-0 material-ripple lighten-5 w-full black-text mt-4 modal-close">My account</a>
            <a href="//support.smartlist.ga" style="width:50%" target="_blank" class="btn btn-border btn-rounded transparent z-depth-0 material-ripple w-full black-text mt-4 modal-close">Help</a>
        </div>
      </div>
    </div>

    <ul class="sidenav sidenav-fixed sidenav-close" id="sidenav-drawer">
      <li class="no-margin"><a class="subheader hide-on-med-and-down">Home</a></li>
      <li class="hide-on-med-and-down"><a class="material-ripple" href="#/dashboard"><i class="material-icons">dashboard</i>Overview</a></li>
      <li class="hide-on-med-and-down"><a class="material-ripple" href="#/my-finances"><i class="material-icons">payments</i>Finances</a></li>
      <li class="hide-on-med-and-down"><a class="material-ripple" href="#/meal-planner"><i class="material-icons">lunch_dining</i><span class="align-middle">Meal planner</span></a></li>
      
      <li class="hide-on-med-and-down"><a class="material-ripple modal-trigger" data-target="add.list" id="add.list.trigger" href="javascript:void(0)"><i class="material-icons">playlist_add</i>Create list</a></li>

      <li><div class="divider hide-on-med-and-down"></div></li>
      <li class="no-margin"><a class="subheader">Rooms</a></li>

      <li><a class="material-ripple" href="#/rooms/kitchen"><i class="material-icons">microwave</i>Kitchen</a></li>
      <li><a class="material-ripple" href="#/rooms/garage"><i class="material-icons">garage</i>Garage</a></li>
      <li><a class="material-ripple" href="#/rooms/bedroom"><i class="material-icons">bedroom_parent</i>Bedroom</a></li>
      <li><a class="material-ripple" href="#/rooms/bathroom"><i class="material-icons">bathroom</i>Bathroom</a></li>
      <li><a class="material-ripple" href="#/rooms/living-room"><i class="material-icons">living</i>Living room</a></li>
      <li><a class="material-ripple" href="#/rooms/dining-room"><i class="material-icons">dining</i>Dining room</a></li>
      <li><a class="material-ripple" href="#/rooms/laundry-room"><i class="material-icons">local_laundry_service</i>Laundry room</a></li>

      <li><a class="material-ripple" href="#/rooms/storage-room"><i class="material-icons">inventory_2</i>Storage room</a></li>
      <li><a class="material-ripple" href="#/rooms/camping-supplies"><i class="material-icons">landscape</i>Camping</a></li>

      <li id="CustomRoomHeader"><div class="divider"></div></li>
      <li><a class="material-ripple" href="#/rooms/create"><i class="material-icons">add_location_alt</i>Create room</a></li>

      <li><div class="divider"></div></li>
      <li class="no-margin"><a class="subheader">Other</a></li>

      <li><a class="material-ripple" href="#/notes"><i class="material-icons">sticky_note_2</i>Notes</a></li>
      <li><a class="material-ripple" href="#/starred"><i class="material-icons">star</i>Starred</a></li>
      <li><a class="material-ripple" href="#/trash"><i class="material-icons">delete</i>Trash</a></li>
      <li><a class="material-ripple" href="#/maintenance"><i class="material-icons">construction</i>Maintenance</a></li>

      <li class="hide-on-med-and-down"><div class="divider"></div></li>
      <li class="no-margin hide-on-med-and-down"><a class="subheader">Account</a></li>
      <li class="hide-on-med-and-down"><a class="material-ripple" href="#/settings"><i class="material-icons">settings</i>Settings</a></li>
      <li class="hide-on-med-and-down"><a class="material-ripple" href="#/notifications" class="hide-on-med-and-down"><i class="material-icons">notifications</i>Notifications</a></li>
    </ul>

    <div id="app">
      <div class="loader-container"> <svg width="38" height="38" viewBox="0 0 38 38" xmlns="http://www.w3.org/2000/svg" stroke="#000" style="margin-top: -65px"> <g fill="none" fill-rule="evenodd"> <g transform="translate(1 1)" stroke-width="2"> <circle stroke-opacity=".1" cx="18" cy="18" r="18"/> <path d="M36 18c0-9.94-8.06-18-18-18"> <animateTransform attributeName="transform" type="rotate" from="0 18 18" to="360 18 18" dur=".8s" repeatCount="indefinite"/> </path> </g> </g> </svg> </div>
    </div>
    <div class="btn-fixed">
      <a class="modal-trigger bg-theme black-text btn btn-large material-ripple z-depth-0" id="fab" href="javascript:void(0)" data-target="addItem">
        <i class="left material-icons-outlined">edit</i>
        <span>Create</span>
      </a>
    </div>
    <div class="modal-swipe bg-theme modal h-auto bottom-sheet modal-rounded modal-1/2-width black-text" id="addItem">
      <div class="modal-content center">
        <div class="center">
          <h5 class="mb-10">Create new</h5>

          <div class="row no-margin">
            <a href="#/add/kitchen" class="col s3 card-add material-ripple black-text modal-close">
              <i class="material-icons">microwave</i>
              <p class="truncate">Kitchen</p>
            </a>
            <a href="#/add/garage" class="col s3 card-add material-ripple black-text modal-close">
              <i class="material-icons">garage</i>
              <p class="truncate">Garage</p>
            </a>
            <a href="#/add/bedroom" class="col s3 card-add material-ripple black-text modal-close">
              <i class="material-icons">bedroom_parent</i>
              <p class="truncate">Bedroom</p>
            </a>
            <a href="#/add/bathroom" class="col s3 card-add material-ripple black-text modal-close">
              <i class="material-icons">bathroom</i>
              <p class="truncate">Bathroom</p>
            </a>
            <a href="#/add/family" class="col s3 card-add material-ripple black-text modal-close">
              <i class="material-icons">living</i>
              <p class="truncate">Family</p>
            </a>
            <a href="#/add/dining-room" class="col s3 card-add material-ripple black-text modal-close">
              <i class="material-icons">dining</i>
              <p class="truncate">Dining</p>
            </a>
            <a href="#/add/laundry-room" class="col s3 card-add material-ripple black-text modal-close">
              <i class="material-icons">local_laundry_service</i>
              <p class="truncate">Laundry</p>
            </a>
            <a href="javascript:void(0)" class="col s3 card-add material-ripple black-text dropdown-trigger" data-target="otherDropdown">
              <i class="material-icons">more_horiz</i>
              <p class="truncate">More</p>
            </a>
            <ul class="dropdown-content modal-close" id="otherDropdown">
              <li><a href="#/add/storage" class="material-ripple"><i class="material-icons left">inventory_2</i>Storage room</a></li>
              <li><a href="#/add/camping" class="material-ripple"><i class="material-icons left">landscape</i>Camping supplies</a></li>
            </ul>
          </div>
          <div class="divider"></div>
          <div class="row no-margin">
            <div class="col s3 card-add material-ripple modal-trigger modal-close" data-target="add.finance" id="add.finance.trigger">
              <i class="material-icons">payments</i>
              <p class="truncate">Expense</p>
            </div>
            <div class="col s3 card-add material-ripple modal-trigger modal-close" data-target="add.shoppingList" id="add.shoppingList.trigger">
              <i class="material-icons">receipt_long</i>
              <p class="truncate">Shopping List</p>
            </div>
            <div class="col s3 card-add material-ripple modal-trigger modal-close" data-target="add.reminder" id="add.reminder.trigger">
              <i class="material-icons">check</i>
              <p class="truncate">Reminder</p>
            </div>
            <div class="col s3 card-add material-ripple modal-trigger modal-close" data-target="add.note" id="add.note.trigger">
              <i class="material-icons">sticky_note_2</i>
              <p class="truncate">Note</p>
            </div>
          </div>

        </div>
      </div>
    </div>





    <div class="modal transparent z-depth-0" id="search">
      <div>
        <input 
               class="browser-default search" 
               placeholder="Find anything...">
        <a class="waves-center close modal-close"> <i class="material-icons black-text">close</i> </a>

        <div class="collection white" id="searchResults"></div>
      </div>
    </div>  


    <div id="add.finance" class="modal modal-rounded bottom-sheet modal-1/2-width">
      <form
            action="https://smartlist.ga/app/user/finance/addFinance.php"
            id="add.finance.form"
            >
        <div class="modal-content">
          <div style="display: flex; align-items: center; gap: 10px">
            <span class="prefix" style="font-size: 40px; margin-top: -15px">$</span>
            <input
                   type="text"
                   name="n"
                   required
                   id="addFinanceSpent"
                   pattern="[0-9.]+"
                   autocomplete="off"
                   autofocus
                   style="font-size: 35px; border-color: #ccc !important; padding: 10px"
                   class="z-depth-0"
                   placeholder="Money spent"
                   />
          </div>
          <div>
            <div class="input-border input-field">
              <select id="add.finance.form.label" name="label">
                <option value="Grocery Shopping">Grocery Shopping</option>
                <option value="Clothes Shopping">Clothes Shopping</option>
                <option value="Education">Education</option>
                <option value="Bills">Bills</option>
                <option value="Entertainment">Entertainment</option>
                <option value="Home Improvement">Home Improvement</option>
                <option value="Holidays">Holidays</option>
                <option value="Other">Other</option>
              </select>
            </div>
          </div>
          <button
                  type="submit"
                  name="Submit"
                  style="width: 100%"
                  class="hide-on-med-and-down btn btn-boxy z-depth-0 material-ripple btn-large black-text blue-grey lighten-3"
                  >
            <i class="material-icons left hide-on-med-and-down">save</i>Save
          </button>
          <div
               style="padding: 10px; background: var(--bg-color); width: 100%; z-index: 99999; position: fixed; bottom: 0; left: 0;"
               class="hide-on-large-only"
               >
            <div class="row center keypad">
              <div class="col s3"> <div class="number material-ripple" onclick="bmNumber(this.innerText)"> <span>1</span> </div> <div class="number material-ripple" onclick="bmNumber(this.innerText)"> <span>4</span> </div> <div class="number material-ripple" onclick="bmNumber(this.innerText)"> <span>7</span> </div> </div> 
              <div class="col s3"> <div class="number material-ripple" onclick="bmNumber(this.innerText)"> <span>2</span> </div> <div class="number material-ripple" onclick="bmNumber(this.innerText)"> <span>5</span> </div> <div class="number material-ripple" onclick="bmNumber(this.innerText)"> <span>8</span> </div> </div>
              <div class="col s3"> <div class="number material-ripple" onclick="bmNumber(this.innerText)"> <span>3</span> </div> <div class="number material-ripple" onclick="bmNumber(this.innerText)"> <span>6</span> </div> <div class="number material-ripple" onclick="bmNumber(this.innerText)"> <span>9</span> </div> </div>
              <div class="col s3"> <div class="number material-ripple red-text text-darken-3" onclick="bmNumber(this.innerText)" > <i class="material-icons">backspace</i> </div> <div class="number material-ripple" onclick="bmNumber(this.innerText)"> . </div> </div> <div class="col s12"></div> <div class="col s9"> <div class="number material-ripple" onclick="bmNumber(this.innerText)"> <span>0</span> </div> </div> <div class="col s3"> <button class="number material-ripple green lighten-5 white-text"> <i class="material-icons black-text">check</i> </button> </div>
            </div>
          </div>
        </div>
      </form>
    </div>

    <div class="modal modal-rounded modal-center" id="add.reminder">
      <div class="modal-content">
        <h5 class="mb-10">Create reminder</h5>
        <form action="/app/user/todo/add.php" id="add.reminder.form" method="POST">
          <div class="input-field input-border">
            <input type="text" name="name" required utocomplete="off" id="add.reminder.form.name">
            <label>Title</label>
          </div>
          <div class="input-field input-border">
            <input type="text" name="price" required class="datepicker" autocomplete="off">
            <label>Date</label>
          </div>
          <div class="input-field input-border">
            <input type="text" name="decs" required autocomplete="off">
            <label>Description (optional)</label>
          </div>
          <div class="input-field input-border">
            <input type="number" name="qty" required min='0' max='5' autocomplete="off">
            <label>Priority</label>
          </div>
          <button class="modal-close btn z-depth-0 bg-theme btn-large rounded-lg black-text material-ripple"><i class="material-icons left">save</i>Create</button>

        </form>
      </div>
    </div>


    <div class="modal modal-rounded modal-center" id="add.note">
      <div class="modal-content">
        <h5 class="mb-10">Create note</h5>
        <form action="/app/user/notes/add.php" id="add.note.form" method="POST">
          <div class="input-field input-border">
            <input type="text" name="name" required autocomplete="off" id="add.note.form.name">
            <label>Title</label>
          </div>
          <div class="input-field input-border">
            <input type="text" name="url" autocomplete="off" id="add.note.form.url">
            <label>Note banner (Image URL, optional)</label>
          </div>

          <button class="modal-close btn z-depth-0 bg-theme btn-large rounded-lg black-text material-ripple"><i class="material-icons left">save</i>Create</button>

        </form>
      </div>
    </div>
    <div class="modal modal-rounded modal-center" id="add.shoppingList">
      <div class="modal-content">
        <h5 class="mb-3">Create item</h5>
        <p class="grey-text text-darken-2">Shopping list</p>
        <form action="/app/user/grocerylist/add.php" id="add.shoppingList.form" method="POST">
          <div class="input-field input-border">
            <input type="text" name="name" required autocomplete="off" id="add.shoppingList.form.name">
            <label>Title</label>
          </div>

          <button class="modal-close btn z-depth-0 bg-theme btn-large rounded-lg black-text material-ripple"><i class="material-icons left">save</i>Create</button>

        </form>
      </div>
    </div>
    <div class="modal modal-rounded modal-center" id="add.list">
      <div class="modal-content">
        <h5 class="mb-10">Create list</h5>
        <form action="https://smartlist.ga/app/user/lists/add.php" method="POST" id="add.list.form">
          <div class="input-field input-border">
            <input type="text" name="name" required autocomplete="off" id="add.list.form.name">
            <label>Title</label>
          </div>
          <p>
            <label>
              <input type="checkbox" class="filled-in" checked="checked" name="star"/>
              <span>Favorite?</span>
            </label>
          </p>
          <button class="modal-close btn z-depth-0 bg-theme btn-large rounded-lg black-text material-ripple"><i class="material-icons left">save</i>Create</button>

        </form>
      </div>
    </div>



    <div class="modal modal-rounded modal-center" id="shortcuts">
      <div class="modal-content">
        <h5 class="mb-10">Keyboard shortcuts</h5>
        <p>Create item <br><span class="grey-text text-darken-2">CTRL + S</span></p>
        <p>Create task <br><span class="grey-text text-darken-2">CTRL + L</span></p>
        <p>Search <br><span class="grey-text text-darken-2">CTRL + K</span></p>
        <p>Create expense <br><span class="grey-text text-darken-2">CTRL + B</span></p>
        <p>Create note <br><span class="grey-text text-darken-2">CTRL + M</span></p>
        <p>New item in Shopping list <br><span class="grey-text text-darken-2">CTRL + G</span></p>
      </div>
    </div>
    <div id="note.viewModal" class="modal modal-fullscreen"></div>
    <div class="material-sidenav" id="item_sidenav"></div>




    <script defer src="https://cdn.jsdelivr.net/npm/@editorjs/editorjs@latest"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/@editorjs/header@latest"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/@editorjs/list@latest"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/@editorjs/quote@latest"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/@editorjs/checklist@latest"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/@editorjs/image@2.3.0"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/@editorjs/image@2.3.0"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/@editorjs/table@2.0.1/dist/table.min.js"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/@editorjs/simple-image@latest"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/@editorjs/marker@latest"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/@editorjs/code"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/@editorjs/underline@latest"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/@editorjs/paragraph"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/@editorjs/warning@latest"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/@editorjs/delimiter"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/@editorjs/inline-code"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/editorjs-paragraph-with-alignment@3.0.0"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/editorjs-alert@latest"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/editorjs-drag-drop@1.0.2/dist/bundle.min.js"></script>

    <script type="module">
      import {getHashPage} from './js/pages.js'
    </script>
    <script defer src="./js/app.js"></script>
    <script defer src="./js/init.js"></script>
    <script>
    window.dispatchEvent(new Event("fetchedUserInfo"))

    fetch('https://api.smartlist.ga/v2/rooms/', {
        method: "POST",
        body: "token=<?=$_COOKIE['UserToken'];?>",
        headers: { "Content-Type": "application/x-www-form-urlencoded" }
    })
    .then(res => res.json())
    .then(res => {
       res.data.forEach(d => {
           var id = CryptoJS.SHA256(d.id.toString()).toString()
           document.getElementById("CustomRoomHeader").insertAdjacentHTML("afterend", `<li><a class="material-ripple" href="#/rooms/${id}"><i class="material-icons">label</i>${d.name}</a></li>`);
        window._pages[`/add/${id}`] = `/app/rooms/custom_room/add.php?room=${id}`;
        window._pages[`/rooms/${id}`] = `/app/rooms/custom_room/add.php?room=${id}`;
       });
       document.querySelectorAll("#sidenav-drawer li a:not(.subheader)").forEach(el => {
            el.addEventListener("click", ()=> {
                if(document.querySelector(".sidenav-active")) document.querySelectorAll(".sidenav-active").forEach(d => d.classList.remove('sidenav-active'));
                el.classList.add("sidenav-active")
            })
        })

    })
  
    window._user = <?=json_encode($_USER->data, JSON_PRETTY_PRINT)?>
    </script>
  </body>
</html>