<?php
class Encryption extends App {
    public function encrypt(string $textToEncrypt) {
        $key = substr(hash('sha256', App::encryptionKey, true), 0, 32);
        $cipher = App::encryptionAlgorithm;
        $iv_len = openssl_cipher_iv_length($cipher);
        $tag_length = 16;
        $iv = openssl_random_pseudo_bytes($iv_len);
        $tag = ""; // will be filled by openssl_encrypt
        
        $ciphertext = openssl_encrypt($textToEncrypt, $cipher, $key, OPENSSL_RAW_DATA, $iv, $tag, "", $tag_length);
        $encrypted = base64_encode($iv.$ciphertext.$tag);
        return $encrypted;
    }
    public function decrypt(string $textToDecrypt) {
        $encrypted = base64_decode($textToDecrypt);
        $key = substr(hash('sha256', App::encryptionKey, true), 0, 32);
        $cipher = App::encryptionAlgorithm;
        $iv_len = openssl_cipher_iv_length($cipher);
        $tag_length = 16;
        $iv = substr($encrypted, 0, $iv_len);
        $ciphertext = substr($encrypted, $iv_len, -$tag_length);
        $tag = substr($encrypted, -$tag_length);
        
        $decrypted = openssl_decrypt($ciphertext, $cipher, $key, OPENSSL_RAW_DATA, $iv, $tag);
        return $decrypted;
    }
}