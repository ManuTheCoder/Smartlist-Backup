<?php
	require "../cred.php";
?>
<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Login - Smartlist</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="shortcut icon" href="https://smartlist.ga/app/img/logo/48x48.png">
  <link href="https://visionly.manuthecoder.repl.co/dist/output.css" rel="stylesheet">
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            clifford: '#da373d',
          }
        }
      }
    }
  </script>
	<style>
	 .bg{
        background-size: cover;
background-image: url("data:image/svg+xml,%0A%3Csvg id='visual' viewBox='0 0 675 900' width='675' height='900' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' version='1.1'%3E%3Crect x='0' y='0' width='675' height='900' fill='%2300cc8e'%3E%3C/rect%3E%3Cdefs%3E%3ClinearGradient id='grad1_0' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%23001122' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%23001122' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad1_1' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%23001122' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%23002c44' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad1_2' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%23004a64' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%23002c44' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad1_3' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%23004a64' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%2300697d' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad1_4' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%23008a8d' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%2300697d' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad1_5' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%23008a8d' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%2300ab92' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad1_6' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%2300cc8e' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%2300ab92' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad2_0' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%23001122' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%23001122' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad2_1' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%23002c44' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%23001122' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad2_2' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%23002c44' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%23004a64' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad2_3' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%2300697d' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%23004a64' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad2_4' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%2300697d' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%23008a8d' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad2_5' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%2300ab92' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%23008a8d' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad2_6' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%2300ab92' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%2300cc8e' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cg transform='translate(675, 0)'%3E%3Cpath d='M0 478.1C-66.1 436.1 -132.2 394 -207.5 359.4C-282.8 324.8 -367.4 297.7 -414.1 239.1C-460.7 180.4 -469.4 90.2 -478.1 0L0 0Z' fill='%2300bc91'%3E%3C/path%3E%3Cpath d='M0 409.8C-56.6 373.8 -113.3 337.7 -177.9 308.1C-242.4 278.4 -314.9 255.2 -354.9 204.9C-394.9 154.6 -402.4 77.3 -409.8 0L0 0Z' fill='%23009b91'%3E%3C/path%3E%3Cpath d='M0 341.5C-47.2 311.5 -94.4 281.4 -148.2 256.7C-202 232 -262.4 212.7 -295.8 170.8C-329.1 128.9 -335.3 64.4 -341.5 0L0 0Z' fill='%23007a86'%3E%3C/path%3E%3Cpath d='M0 273.2C-37.8 249.2 -75.5 225.1 -118.6 205.4C-161.6 185.6 -210 170.1 -236.6 136.6C-263.3 103.1 -268.2 51.5 -273.2 0L0 0Z' fill='%23005972'%3E%3C/path%3E%3Cpath d='M0 204.9C-28.3 186.9 -56.6 168.9 -88.9 154C-121.2 139.2 -157.5 127.6 -177.5 102.5C-197.4 77.3 -201.2 38.7 -204.9 0L0 0Z' fill='%23003a55'%3E%3C/path%3E%3Cpath d='M0 136.6C-18.9 124.6 -37.8 112.6 -59.3 102.7C-80.8 92.8 -105 85.1 -118.3 68.3C-131.6 51.5 -134.1 25.8 -136.6 0L0 0Z' fill='%23001f33'%3E%3C/path%3E%3Cpath d='M0 68.3C-9.4 62.3 -18.9 56.3 -29.6 51.3C-40.4 46.4 -52.5 42.5 -59.2 34.2C-65.8 25.8 -67.1 12.9 -68.3 0L0 0Z' fill='%23001122'%3E%3C/path%3E%3C/g%3E%3Cg transform='translate(0, 900)'%3E%3Cpath d='M0 -478.1C77 -455 154 -431.9 228 -394.9C302 -358 372.9 -307.2 414.1 -239.1C455.2 -170.9 466.7 -85.5 478.1 0L0 0Z' fill='%2300bc91'%3E%3C/path%3E%3Cpath d='M0 -409.8C66 -390 132 -370.2 195.4 -338.5C258.8 -306.8 319.6 -263.3 354.9 -204.9C390.2 -146.5 400 -73.3 409.8 0L0 0Z' fill='%23009b91'%3E%3C/path%3E%3Cpath d='M0 -341.5C55 -325 110 -308.5 162.9 -282.1C215.7 -255.7 266.3 -219.4 295.8 -170.8C325.2 -122.1 333.3 -61.1 341.5 0L0 0Z' fill='%23007a86'%3E%3C/path%3E%3Cpath d='M0 -273.2C44 -260 88 -246.8 130.3 -225.7C172.6 -204.5 213.1 -175.5 236.6 -136.6C260.1 -97.7 266.7 -48.8 273.2 0L0 0Z' fill='%23005972'%3E%3C/path%3E%3Cpath d='M0 -204.9C33 -195 66 -185.1 97.7 -169.2C129.4 -153.4 159.8 -131.7 177.5 -102.5C195.1 -73.3 200 -36.6 204.9 0L0 0Z' fill='%23003a55'%3E%3C/path%3E%3Cpath d='M0 -136.6C22 -130 44 -123.4 65.1 -112.8C86.3 -102.3 106.5 -87.8 118.3 -68.3C130.1 -48.8 133.3 -24.4 136.6 0L0 0Z' fill='%23001f33'%3E%3C/path%3E%3Cpath d='M0 -68.3C11 -65 22 -61.7 32.6 -56.4C43.1 -51.1 53.3 -43.9 59.2 -34.2C65 -24.4 66.7 -12.2 68.3 0L0 0Z' fill='%23001122'%3E%3C/path%3E%3C/g%3E%3C/svg%3E");      }
			@media only screen and (prefers-color-scheme: dark) {
				.bg {
        background-size: cover!important;
background-image: url("data:image/svg+xml,%0A%3Csvg id='visual' viewBox='0 0 675 900' width='675' height='900' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' version='1.1'%3E%3Crect x='0' y='0' width='675' height='900' fill='%23001220'%3E%3C/rect%3E%3Cdefs%3E%3ClinearGradient id='grad1_0' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%23fbae3c' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%23fbae3c' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad1_1' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%23fbae3c' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%23f17c53' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad1_2' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%23cc5867' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%23f17c53' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad1_3' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%23cc5867' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%2396446e' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad1_4' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%23593762' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%2396446e' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad1_5' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%23593762' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%23232745' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad1_6' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%23001220' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%23232745' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad2_0' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%23fbae3c' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%23fbae3c' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad2_1' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%23f17c53' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%23fbae3c' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad2_2' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%23f17c53' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%23cc5867' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad2_3' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%2396446e' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%23cc5867' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad2_4' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%2396446e' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%23593762' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad2_5' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%23232745' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%23593762' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cdefs%3E%3ClinearGradient id='grad2_6' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='30%25' stop-color='%23232745' stop-opacity='1'%3E%3C/stop%3E%3Cstop offset='70%25' stop-color='%23001220' stop-opacity='1'%3E%3C/stop%3E%3C/linearGradient%3E%3C/defs%3E%3Cg transform='translate(675, 0)'%3E%3Cpath d='M0 478.1C-66.1 436.1 -132.2 394 -207.5 359.4C-282.8 324.8 -367.4 297.7 -414.1 239.1C-460.7 180.4 -469.4 90.2 -478.1 0L0 0Z' fill='%230f1d33'%3E%3C/path%3E%3Cpath d='M0 409.8C-56.6 373.8 -113.3 337.7 -177.9 308.1C-242.4 278.4 -314.9 255.2 -354.9 204.9C-394.9 154.6 -402.4 77.3 -409.8 0L0 0Z' fill='%233d3056'%3E%3C/path%3E%3Cpath d='M0 341.5C-47.2 311.5 -94.4 281.4 -148.2 256.7C-202 232 -262.4 212.7 -295.8 170.8C-329.1 128.9 -335.3 64.4 -341.5 0L0 0Z' fill='%23773d6b'%3E%3C/path%3E%3Cpath d='M0 273.2C-37.8 249.2 -75.5 225.1 -118.6 205.4C-161.6 185.6 -210 170.1 -236.6 136.6C-263.3 103.1 -268.2 51.5 -273.2 0L0 0Z' fill='%23b34c6d'%3E%3C/path%3E%3Cpath d='M0 204.9C-28.3 186.9 -56.6 168.9 -88.9 154C-121.2 139.2 -157.5 127.6 -177.5 102.5C-197.4 77.3 -201.2 38.7 -204.9 0L0 0Z' fill='%23e1685e'%3E%3C/path%3E%3Cpath d='M0 136.6C-18.9 124.6 -37.8 112.6 -59.3 102.7C-80.8 92.8 -105 85.1 -118.3 68.3C-131.6 51.5 -134.1 25.8 -136.6 0L0 0Z' fill='%23f99447'%3E%3C/path%3E%3Cpath d='M0 68.3C-9.4 62.3 -18.9 56.3 -29.6 51.3C-40.4 46.4 -52.5 42.5 -59.2 34.2C-65.8 25.8 -67.1 12.9 -68.3 0L0 0Z' fill='%23fbae3c'%3E%3C/path%3E%3C/g%3E%3Cg transform='translate(0, 900)'%3E%3Cpath d='M0 -478.1C77 -455 154 -431.9 228 -394.9C302 -358 372.9 -307.2 414.1 -239.1C455.2 -170.9 466.7 -85.5 478.1 0L0 0Z' fill='%230f1d33'%3E%3C/path%3E%3Cpath d='M0 -409.8C66 -390 132 -370.2 195.4 -338.5C258.8 -306.8 319.6 -263.3 354.9 -204.9C390.2 -146.5 400 -73.3 409.8 0L0 0Z' fill='%233d3056'%3E%3C/path%3E%3Cpath d='M0 -341.5C55 -325 110 -308.5 162.9 -282.1C215.7 -255.7 266.3 -219.4 295.8 -170.8C325.2 -122.1 333.3 -61.1 341.5 0L0 0Z' fill='%23773d6b'%3E%3C/path%3E%3Cpath d='M0 -273.2C44 -260 88 -246.8 130.3 -225.7C172.6 -204.5 213.1 -175.5 236.6 -136.6C260.1 -97.7 266.7 -48.8 273.2 0L0 0Z' fill='%23b34c6d'%3E%3C/path%3E%3Cpath d='M0 -204.9C33 -195 66 -185.1 97.7 -169.2C129.4 -153.4 159.8 -131.7 177.5 -102.5C195.1 -73.3 200 -36.6 204.9 0L0 0Z' fill='%23e1685e'%3E%3C/path%3E%3Cpath d='M0 -136.6C22 -130 44 -123.4 65.1 -112.8C86.3 -102.3 106.5 -87.8 118.3 -68.3C130.1 -48.8 133.3 -24.4 136.6 0L0 0Z' fill='%23f99447'%3E%3C/path%3E%3Cpath d='M0 -68.3C11 -65 22 -61.7 32.6 -56.4C43.1 -51.1 53.3 -43.9 59.2 -34.2C65 -24.4 66.7 -12.2 68.3 0L0 0Z' fill='%23fbae3c'%3E%3C/path%3E%3C/g%3E%3C/svg%3E");      }
			}
			</style>
</head>
<body class="bg-white dark:bg-gray-900">

    <div class="bg-white dark:bg-gray-900">
        <div class="lg:flex justify-center h-screen">
            <div class="lg:static fixed top-0 left-0 z-50 duration-200 transition-all bg-cover w-screen h-screen lg:block lg:w-7/12 bg" id="intro">
                <div class="flex items-end h-full p-10 bg-gray-9020">
                    <div class="lg:hidden">
                        <h2 class="text-4xl font-bold text-white lg:hidden">Smartlist</h2>
                        
                        <p class="max-w-xl mt-3 text-gray-300 lg:hidden">Smartlist is a free home &amp; business inventory and finance manager app</p>
                        <button class="w-full px-5 py-4 rounded-lg text-white text-left mt-3" style="background:rgba(200,200,200,.4)">Sign up</button>
                        <button class="w-full px-5 py-4 rounded-lg border-gray-700 bg-gray-700 text-white text-left border mt-3" onclick="document.getElementById('intro').style.left='-100vw';document.getElementById('container').style.left='0'">Sign in</button>
                    </div>
                </div>
            </div>
            
            <div class="lg:static fixed flex w-screen duration-200 transition-all lg:max-w-md justify-center h-screen items-center w-full px-6 mx-auto lg:w-5/12" style="left:100vw;width:100vw" id="container">
                <div class="flex-1">
                    <div class="text-center">
                        <h2 class="text-4xl font-bold text-center text-gray-700 dark:text-white">Welcome back!</h2>
                        
                        <p class="mt-3 text-gray-500 dark:text-gray-300">Sign in to your Smartlist account to view your inventory, lists, finances, and more.</p>
                    </div>

                    <div class="mt-8">
                        <form action="<?=App::directory?>/login/authenticate.php" method="POST">
                            <div>
                                <label for="email" class="block mb-2 text-sm text-gray-600 dark:text-gray-200">Your email</label>
                                <input type="email" name="email" id="email" placeholder="hello@smartlist.ga" class="block w-full px-4 py-2 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-emerald-400 dark:focus:border-emerald-400 focus:ring-emerald-400 focus:outline-none focus:ring-2 focus:ring-2-opacity-40" />
                            </div>

                            <div class="mt-6">
                                <div class="flex justify-between mb-2">
                                    <label for="password" class="text-sm text-gray-600 dark:text-gray-200">Password</label>
                                    <a href="#" class="text-sm text-gray-400 focus:text-emerald-500 hover:text-emerald-500 hover:underline outline-none">Forgot?</a>
                                </div>

                                <input type="password" name="password" id="password" placeholder="••••••••••" class="block w-full px-4 py-2 mt-2 text-gray-700 placeholder-gray-400 bg-white border border-gray-200 rounded-md dark:placeholder-gray-600 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-700 focus:border-emerald-400 dark:focus:border-emerald-400 focus:ring-emerald-400 focus:outline-none focus:ring-2 focus:ring-2-opacity-40" />
                            </div>

                            <div class="mt-6">
                                <button
                                    class="w-full px-4 py-2 tracking-wide text-white transition-colors duration-200 transform bg-emerald-500 rounded-md hover:bg-emerald-400 focus:outline-none focus:bg-emerald-400 focus:ring-2 focus:ring-emerald-300 focus:ring-2-opacity-50">
                                    Continue
                                </button>
                            </div>

                        </form>

                        <p class="mt-6 text-sm text-center text-gray-400">Don&#x27;t have an account yet? <a href="#" class="text-emerald-500 focus:outline-none focus:underline hover:underline">Create an account - It's free!</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>