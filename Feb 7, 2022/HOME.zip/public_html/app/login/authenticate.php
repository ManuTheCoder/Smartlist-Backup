<?php
ini_set('display_errors', 1);
include("../cred.php");
include("../encrypt.php");
try {
    $dbh = new PDO("mysql:host=" . App::server . ";dbname=" . App::database, App::user, App::password);
    $dbh->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    $sql = $dbh->prepare("SELECT * FROM Accounts");
    $sql->execute();
    $users = $sql->fetchAll();
    $found = false;
    foreach ($users as $row) {
        $e = new Encryption();
        if($e->decrypt($row['email']) == $_POST['email']) {
            if(password_verify($_POST['password'], $row['password'])) {
                $found = true;
                $token = bin2hex(random_bytes(300));
                $sql = $dbh->prepare("INSERT INTO UserTokens (user, token) VALUES (:user, :token)");
                $sql->execute(array(
                    ":user" => $row['id'],
                    ":token" => $token
                ));
                setcookie( 'UserToken', $token, time() +2592000, '/', 'smartlist.ga' );
                header("Location: /app/");
                break;
            }
        }
    }
    if(!$found) {
        echo "Invalid email!";
    }
}
catch (PDOException $e) {var_dump($e);}