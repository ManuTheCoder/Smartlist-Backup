<?php
ini_set('display_errors', 1);
if (!defined('CURL_HTTP_VERSION_3')) {
    define('CURL_HTTP_VERSION_3', 30);
}
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.smartlist.ga/v2/finances/',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_3,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => 'token='.$_COOKIE['UserToken'],
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/x-www-form-urlencoded'
  ),
));
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($curl, CURLOPT_POSTFIELDS, 'token='.$_COOKIE['UserToken']);

$financeData = json_decode(curl_exec($curl));

curl_close($curl);

function returnUniqueProperty($array,$property) {
  $tempArray = array_unique(array_column($array, $property));
  $moreUniqueArray = array_values(array_intersect_key($array, $tempArray));
  return $moreUniqueArray;
}
?>

<header class="header green darken-3 center white-text" id="header" style="background:url(https://i.ibb.co/Lp2PnkH/blurry-gradient-haikei-1.png);background-size:cover;background-repeat:no-repeat">
    <h1>$127</h1>
    <h6>out of $500</h6>
    <section class="mt-5" style="white-space:nowrap;overflow-x:scroll;width:100%"><div class="container">
        <button class="z-depth-0 material-ripple material-ripple@light btn z-depth-0 btn-rounded" style="margin:5px;background:rgba(0, 0, 0,.1)">Today</button>
        <button class="z-depth-0 material-ripple material-ripple@light btn z-depth-0 btn-rounded" style="margin:5px;background:rgba(0, 0, 0,.1)">Week</button>
        <button class="z-depth-0 material-ripple material-ripple@light btn z-depth-0 btn-rounded" style="margin:5px;background:rgba(0, 0, 0,.1)">Month</button>
        <button class="z-depth-0 material-ripple material-ripple@light btn z-depth-0 btn-rounded" style="margin:5px;background:rgba(0, 0, 0,.1)">Year</button>
        <button class="z-depth-0 material-ripple material-ripple@light btn z-depth-0 btn-rounded" style="margin:5px;background:rgba(0, 0, 0,.1)">All</button>
    </div></section>
</header>
<div style="padding: 10px;">
<div class="mt-3">
    <div class="row">
        <div id="dates"></div>
        <div class="card-panel z-depth-0 card-border card-rounded">
            <h5 class="my-5">Recent</h5>
            <div class="date-container my-3">
                <?php 
                $d = returnUniqueProperty($financeData->data, 'date');
                foreach($d as $data) {
                    $now = new DateTime();
                    $date = DateTime::createFromFormat('m/d/Y', $data->date);
                    ?>
                    <div class="date">
                        <span style="font-size: 13px"><?=$date->format('M')?></span>
                        <span class="grey-text text-darken-2" style="font-size: 17px"><?=$date->format('d')?></span>
                    </div>
                <?php } ?>
            </div>
            <ul class="collection">
                <?php foreach($financeData->data as $data) {?>
                    <li class="collection-item avatar">
                    <i class="material-icons circle red accent-1 black-text">play_arrow</i>
                        <h6 class="my-1 mb-3" style="font-size:20px">$<?=$data->amount?></h6>
                        <p class="grey-text text-darken-3"><?=$data->spentOn?></p>
                        <a href="javascript:void(0)" class="transparent secondary-content tranparent btn-floating z-depth-0 material-ripple"><i class="material-icons black-text">more_vert</i></a>
                    </li>
                <?php } ?>
            </div>
        </div>
    </div>
</div>
</div>
<script>
    document.querySelector(".date-container").scrollLeft = 999999999999999999999999;

    // window.addEventListener("scroll", (e) => {
    //     var header = document.getElementById("header");
    //     if(header) {
    //         if(window.pageYOffset > 0) {
    //             header.classList.add("concise")
    //             header.style.maxHeight=window.pageYOffset - document.body.scrollHeight+"px"
    //             header.style.minHeight=window.pageYOffset - document.body.scrollHeight+"px"
    //         }
    //         else {
    //             header.classList.remove("concise");
    //             header.style.minHeight=""
    //             header.style.maxHeight=""
    //         }
    //     }
    // })
</script>