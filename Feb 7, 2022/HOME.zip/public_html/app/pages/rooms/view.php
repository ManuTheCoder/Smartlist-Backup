<?php
if (!defined('CURL_HTTP_VERSION_3')) {
    define('CURL_HTTP_VERSION_3', 30);
}
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.smartlist.ga/v2/items/list/',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_3,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => 'token='.$_COOKIE['UserToken'],
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/x-www-form-urlencoded'
  ),
));
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($curl, CURLOPT_POSTFIELDS, 'token='.$_COOKIE['UserToken']."&room=".$_GET['room']);

$items = json_decode(curl_exec($curl))->data;
?>
<div class="container">
    <h5 class="my-5"><?=ucfirst($_GET['room']);?></h5>
    <div class="chips">
        <div class="chip material-ripple chip-border">Test</div>
        <div class="chip material-ripple chip-border">Test1</div>
        <div class="chip material-ripple chip-border">Test2345</div>
        <div class="chip material-ripple chip-border">Test4325</div>
        <div class="chip material-ripple chip-border">Test3425</div>
        <div class="chip material-ripple chip-border">Tes3245t</div>
        <div class="chip material-ripple chip-border">Test4</div>
        <div class="chip material-ripple chip-border">Test3</div>
        <div class="chip material-ripple chip-border">Tes4t</div>
        <div class="chip material-ripple chip-border">Tes4t</div>
        <div class="chip material-ripple chip-border">Test5</div>
        <div class="chip material-ripple chip-border">Test</div>
        <div class="chip material-ripple chip-border">Test</div>
        <div class="chip material-ripple chip-border">Te4st</div>
        <div class="chip material-ripple chip-border">Tes2345t</div>
    </div>
    <table> 
    <thead>
        <tr class="sticky-top">
            <th><span class="truncate" style="max-width:20vw;">Name</th>
            <th><span class="truncate" style="max-width:20vw;">Quantity</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach($items as $item) {?>
            <tr
                data-id="<?=intval($item->id)?>"
                data-star="<?=intval($item->star)?>"
                data-lastUpdated="<?=htmlspecialchars($item->lastUpdated)?>"
                data-sync="<?=htmlspecialchars($item->sync)?>"
                data-room="<?=htmlspecialchars($_GET['room'])?>"
                data-categories="<?=htmlspecialchars($item->categories)?>"
                onclick="item(this)">
                <td><span class="truncate" style="max-width:20vw;"><?=htmlspecialchars($item->title)?></span></td>
                <td><span class="truncate" style="max-width:20vw;"><?=htmlspecialchars($item->amount)?></span></td>
            </tr>
        <?php }?>
        </tbody>
    </table>
</div>