<section class="card card-border card-rounded grid-item z-depth-0 card-panel" style="width:calc(100% - 20px)">
    <h5 class="my-2 mb-8">Expenses</h5>
    <div class="row">
        <div class="col s4 m4"><h5 class="my-0">$<span id="financeTotal">0</span></h5><p class="grey-text text-darken-3">Spent in total</p></div>
        <div class="col s4 m4"><h5 class="my-0">$<span id="financeMonth">0</span></h5><p class="grey-text text-darken-3">This month</p></div>
        <div class="col s4 m4"><h5 class="my-0">$<span id="financeToday">0</span><span id="financeToday" class="grey-text" style="font-size:15px">/$100</span></h5><p class="grey-text text-darken-3">Today</p></div>

        <div class="col s4 m4"><h5 class="my-0">$<span id="financeMonth">0</span></h5><p class="grey-text text-darken-3">This month</p></div>
        <div class="col s4 m4"><h5 class="my-0">$<span id="financeMonth">0</span></h5><p class="grey-text text-darken-3">This month</p></div>
        <div class="col s4 m4"><h5 class="my-0">$<span id="financeMonth">0</span></h5><p class="grey-text text-darken-3">This month</p></div>
    </div>
</section>
<main class="grid">
    <section class="card card-border card-rounded grid-item z-depth-0 card-panel">
        <h5 class="my-3">Shopping List</h5>
        <div class="collection no-border">
            <a class="collection-item transparent material-ripple">
                <label><input type="checkbox"><span>Test</span></label>
            </a>
         <a class="collection-item transparent material-ripple">
                <label><input type="checkbox"><span>Test</span></label>
            </a>
         <a class="collection-item transparent material-ripple">
                <label><input type="checkbox"><span>Test</span></label>
            </a>
         <a class="collection-item transparent material-ripple">
                <label><input type="checkbox"><span>Test</span></label>
            </a>
         <a class="collection-item transparent material-ripple">
                <label><input type="checkbox"><span>Test</span></label>
            </a>
         <a class="collection-item transparent material-ripple">
                <label><input type="checkbox"><span>Test</span></label>
            </a>
         <a class="collection-item transparent material-ripple">
                <label><input type="checkbox"><span>Test</span></label>
            </a> <a class="collection-item transparent material-ripple">
                <label><input type="checkbox"><span>Test</span></label>
            </a> <a class="collection-item transparent material-ripple">
                <label><input type="checkbox"><span>Test</span></label>
            </a> <a class="collection-item transparent material-ripple">
                <label><input type="checkbox"><span>Test</span></label>
            </a> <a class="collection-item transparent material-ripple">
                <label><input type="checkbox"><span>Test</span></label>
            </a> <a class="collection-item transparent material-ripple">
                <label><input type="checkbox"><span>Test</span></label>
            </a> <a class="collection-item transparent material-ripple">
                <label><input type="checkbox"><span>Test</span></label>
            </a> <a class="collection-item transparent material-ripple">
                <label><input type="checkbox"><span>Test</span></label>
            </a>
        </div>
    </section>
   
    
    <section class="card card-rounded grid-item z-depth-0 card-panel blue accent-3 white-text material-ripple">
        <h5 class="my-3">List1</h5>
        <p class="my-2">69 items</p>
    </section>
    <section class="card card-rounded grid-item z-depth-0 card-panel red accent-3 white-text material-ripple">
        <h5 class="my-3">List1</h5>
        <p class="my-2">69 items</p>
    </section>
    <section class="card card-rounded grid-item z-depth-0 card-panel green accent-3 white-text material-ripple">
        <h5 class="my-3">List1</h5>
        <p class="my-2">69 items</p>
    </section>
    <section class="card card-rounded grid-item z-depth-0 card-panel orange accent-3 white-text material-ripple">
        <h5 class="my-3">List1</h5>
        <p class="my-2">69 items</p>
    </section>
    <section class="card card-rounded grid-item z-depth-0 card-panel pink accent-3 white-text material-ripple">
        <h5 class="my-3">List1</h5>
        <p class="my-2">69 items</p>
    </section>
     <section class="card card-border card-rounded grid-item z-depth-0 card-panel">
        <h5 class="my-3">Reminders</h5>
        <div class="collection no-border">
            <a class="collection-item transparent material-ripple">
                <label><input type="checkbox"><span>Test</span></label>
            </a>
         <a class="collection-item transparent material-ripple">
                <label><input type="checkbox"><span>Test</span></label>
            </a>
         <a class="collection-item transparent material-ripple">
                <label><input type="checkbox"><span>Test</span></label>
            </a>
         <a class="collection-item transparent material-ripple">
                <label><input type="checkbox"><span>Test</span></label>
            </a>
         <a class="collection-item transparent material-ripple">
                <label><input type="checkbox"><span>Test</span></label>
            </a>
         <a class="collection-item transparent material-ripple">
                <label><input type="checkbox"><span>Test</span></label>
            </a>
         <a class="collection-item transparent material-ripple">
                <label><input type="checkbox"><span>Test</span></label>
            </a>
        </div>
    </section>
</main>
<script>
fetch('https://api.smartlist.ga/v2/finances/', {
  method: "POST",
  body: "token=<?=$_COOKIE['UserToken']?>",
  headers: {
    "Content-Type": "application/x-www-form-urlencoded"
  }
})
  .then(res => res.json())
  .then(res => {
    document.getElementById("financeTotal").innerHTML = res.data.reduce((sum,a)=>{ return sum + parseInt(a.amount); },0);

    let curr = new Date();
    let financeMonth = res.data.reduce((sum,a)=>{ 
        let date = new Date(
        a.date.split("/")[2],
        a.date.split("/")[1],
        a.date.split("/")[0]
        );
        if(date.getMonth() == curr.getMonth() && date.getFullYear() == curr.getFullYear()) {
        return sum + parseInt(a.amount);
        }
        else {
            return 0
        }
    },0);
    document.getElementById("financeMonth").innerHTML = financeMonth

    // res.data.forEach(a => {
	//   let curr = new Date();
    //     let date = new Date(
    //     a.date.split("/")[2],
    //     a.date.split("/")[1],
    //     a.date.split("/")[0]
    //     ); 
    //     let curr = new Date();
    //     if(
    //     curr.getDate() == date.getDate() &&
    //     curr.getMonth() == date.getMonth() &&
    //     curr.getFullYear() == date.getFullYear()
    //     ) {
    //     document.getElementById("financeToday").innerHTML = a.amount
    //     }
    // })

  }).catch(err => {
  alert(err)
  })

var elem = document.querySelector('.grid');
var msnry = new Masonry( elem, {
  itemSelector: '.grid-item',
  columnWidth: 200,
});

var msnry = new Masonry( '.grid', {
  // options
});
</script>