<?php
header("Content-Type: text/plain");
http_response_code(403);
die("403");
exit();
ini_set('display_errors', 1);
include("cred.php");
include("old-encrypt.php");
include("encrypt.php");
try {
    $dbh = new PDO("mysql:host=" . App::server . ";dbname=" . App::database, App::user, App::password);
    $dbh->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    $sql = $dbh->prepare("SELECT * FROM Notes");
    $sql->execute();
    $users = $sql->fetchAll();
    foreach ($users as $row) {
        $e = new Encryption();
        $sql = $dbh->prepare("UPDATE Notes SET banner=:v WHERE id=:id");
        $sql->execute(array(
            ":v" => decrypt($row['banner']),
            ":id" => $row['id']
        ));
    }
}
catch (PDOException $e) {var_dump($e);}