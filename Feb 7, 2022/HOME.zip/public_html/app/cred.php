<?php
class App {
    const server = "localhost";
    const user = "smar_master";
    const database = "smar_data";
    const password = 'En#+mG6Kxic@!b@b0amfCE-5q1ps3uAK!-0xFAD5J!fh%5JvPrArt+MJffAo4DmniJOPGn4JFniosp%63Fxy*dF0#eN4sps#*GekFvPvc1yMHhb86J381qmon47gADjB';
    
    const encryptionKey = '/%W#owx@UwYl1+aW*jxAER6>M?G54X|d7m,m:j_5A_trbP=fZ#N4xN6YmjfifSvrtbFnJ=go:=4#2JRHB9dq&?Ak4&HBONhKmbFP</qpy44n$rr9L;BL#./-t6I&O<c5Zk8k|ENXohzLJUIntw@7G^jM=ClG:=;;+\'H=0jVqkhZ?>Xyeuo_W%3me9AH,ry?bppxiD$fL83CCuWy5q^B46OC4nrt$_lG=puT.!#i4w.#Lz+5=Nb4A@6u|_nnZL9.~V#eHROqqb\'7+qt%O2OTqx/zf-%<txKNZ=>sEF<qhRmuJo=2ZD|ENN>f*H_#WZWWaqW5F;0H|/GYCDuv*9&I0y*\'iS>@tDvTY9%ig6jvV4-*%S0-!2T,sNmta|>|.Evq&C?qD;WE!XSOq$RotZ:=*%%82Bc?%%jg-.RGBnA4\'8y0ng0unv~kADS91>^W:9..WO$O4W%ysg!,Vqy2ZzK5xA1<-RW#nO4I>%R9,^0Xf,qwLT8?w\'%yPN1k*oL^#%DK;%2G#N%gOS27\'kSPuW!ruq_D_8nX*+p~66DBR_\'\'E9d?_vtajueUOap8-m:y!GK#kEDOGMmCN$vg3E*TWY*FqK_v>CoXMbd^Ha**~/pBgAD9\'iyxw@@z*6a>3TGf~Z7$L?.Th623/>P^pf_5rdP;fbH9~lE3Rgfs5qOv&A^xK=CBoh9njhijkv_.4D9~@_&aCZEGwjVRs@W#+jmoT|c;@M';

    const apiDatabase = "smar_api";
    const apiUser = "smar_api";
    const apiPassword = "wHzZtLpbigFaUbAzure7FPBzq5dwUAsACjYg978xpwsh4qu3UySMsVvNpfO7S8vNeirvBuBKkXq2xE7GyHXSPSyIZHdVd53W7EUwUya5CtI5sNkErU2yhaPWtEaMPYy4isKcFnLjskUKuKm7ToeGCXz1eW2sX0Xhcelh1Aj87n0HNZvh2bqVkch8LGRYBBV3GaCI1paoYvpRBkvD4P5Kn26f8pC3C2hybV1InGsAj5ytsfzCMZtqa8wRdhpIg87pRBku87ePwVK9U8vHbnhGOlZyqfvNXedm84WZZ2bN11p2NdehumNM7yuoLg30Ef38hkD2BW4fgUNBI4UlcUxiWV7D8fJRr5gbIAd8SmBVASZjwX1B1omVNBwoafeM7lbDZOXK6Dq8TVsszG818MeUbBg1Nca9ccgUnMhdHV2pOSMb37be0EDA56VsBpZryge2k2eIRrVgrAFLPqTDRELqWerWMR4rq6FudrcJhFoP5btVMXwXbgx8";

    const encryptionAlgorithm = "AES-256-GCM";
    const directory = "/app";
}