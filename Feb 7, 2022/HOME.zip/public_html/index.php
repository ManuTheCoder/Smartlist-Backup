
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>
      Smartlist - Smart and easy home inventory and finance management
    </title>
    <script type="application/ld+json">
      {
        "@context": "https://schema.org",
        "@type": "Project",
        "name": "Smartlist",
        "alternateName": "Smartlist",
        "url": "https://smartlist.ga",
        "logo": "https://smartlist.ga/dashboard/icon/roofing.svg",
        "sameAs": ["https://github.com/Smartlist-App", "https://smartlist.ga"]
      }
    </script>
    <title>
      Smartlist - sophisticated home and business inventory management for free.
    </title>
    <meta
      name="title"
      content="Smartlist - sophisticated home and business inventory management for free."
    />
    <meta
      name="description"
      content="Smartlist is a free home inventory app that lets you keep track of what you have in your home. Save money for free by tracking your expenses, getting reminders for home maintenance, and creating shopping lists!"
    />
    <link
      rel="stylesheet"
      href="//matifycss.manuthecoder.repl.co/src/matify.css"
    />
    <script src="//matifycss.manuthecoder.repl.co/src/matify.js"></script>
    <link
      rel="shortcut icon"
      href="https://i.ibb.co/HPtyvJS/logo-z3yoqm-modified-removebg-preview-modified.png"
    />
    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website" />
    <meta property="og:url" content="https://smartlist.ga/" />
    <meta
      property="og:title"
      content="Smartlist - sophisticated home and business inventory management for free."
    />
    <meta
      property="og:description"
      content="Smartlist is a free home inventory app that lets you keep track of what you have in your home. Save money for free by tracking your expenses, getting reminders for home maintenance, and creating shopping lists!"
    />
    <meta property="og:image" content="https://i.ibb.co/1nW9xMJ/banner.png" />
    <script async src="https://cdn.splitbee.io/sb.js"></script>
    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image" />
    <meta property="twitter:url" content="https://smartlist.ga/" />
    <meta
      property="twitter:title"
      content="Smartlist - sophisticated home and business inventory management for free."
    />
    <meta
      property="twitter:description"
      content="Smartlist is a free home inventory app that lets you keep track of what you have in your home. Save money for free by tracking your expenses, getting reminders for home maintenance, and creating shopping lists!"
    />
    <meta
      property="twitter:image"
      content="https://i.ibb.co/1nW9xMJ/banner.png"
    />
		  <link
			rel="stylesheet"
			href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
		/>
    <script src="https://cdn.jsdelivr.net/gh/google/code-prettify@master/loader/run_prettify.js"></script>
    <link
      rel="stylesheet"
      href="https://unpkg.com/@themesberg/flowbite@1.3.0/dist/flowbite.min.css"
    />
    <script
      src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"
      integrity="sha512-Eak/29OTpb36LLo2r47IpVzPBLXnAMPAVypbSZiZ4Qkf8p/7S/XRG5xp7OKWPPYfJT6metI+IORkR5G8F900+g=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    ></script>
    <script src="//cdn.tailwindcss.com"></script>
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Material+Icons|Material+Icons+Outlined|Material+Icons+Two+Tone|Material+Icons+Round|Material+Icons+Sharp"
    />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Outfit&family=Source+Code+Pro:wght@500&display=swap"
      rel="stylesheet"
    />
		<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=Outfit:wght@400;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/@themesberg/flowbite@1.3.0/dist/flowbite.bundle.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/parallax/3.1.0/parallax.min.js"></script>
    <script>
      tailwind.config = {
        // darkMode: 'class'
      };
    </script>
    <style>
      /*! Color themes for Google Code Prettify | MIT License | github.com/jmblog/color-themes-for-google-code-prettify */
      .prettyprint {
        background: #161b1d;
        font-family: Menlo, Bitstream Vera Sans Mono, DejaVu Sans Mono, Monaco,
          Consolas, monospace;
        border: 0 !important;
      }
      .pln {
        color: #ebf8ff;
      }
      ol.linenums {
        margin-top: 0;
        margin-bottom: 0;
        color: #5a7b8c;
      }
      li.L0,
      li.L1,
      li.L2,
      li.L3,
      li.L4,
      li.L5,
      li.L6,
      li.L7,
      li.L8,
      li.L9 {
        padding-left: 1em;
        background-color: #161b1d;
        list-style-type: decimal;
      }
      @media screen {
        .str {
          color: #568c3b;
        }
        .kwd {
          color: #6b6bb8;
        }
        .com {
          color: #5a7b8c;
        }
        .typ {
          color: #257fad;
        }
        .lit {
          color: #935c25;
        }
        .pun {
          color: #ebf8ff;
        }
        .opn {
          color: #ebf8ff;
        }
        .clo {
          color: #ebf8ff;
        }
        .tag {
          color: #d22d72;
        }
        .atn {
          color: #935c25;
        }
        .atv {
          color: #2d8f6f;
        }
        .dec {
          color: #935c25;
        }
        .var {
          color: #d22d72;
        }
        .fun {
          color: #257fad;
        }
      }

      *:not(pre, pre *) {
        font-family: "Outfit", sans-serif;
      }
      @media only screen and (max-width: 992px) {
        .hide-on-med-and-down {
          display: none !important;
        }
      }
      .container {
        margin: 0 auto;
        max-width: 1280px;
        width: 90%;
      }
      @media only screen and (min-width: 601px) {
        .container {
          width: 85%;
        }
      }
      @media only screen and (min-width: 993px) {
        .container {
          width: 70%;
        }
      }
      .bg {
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1440 320'%3E%3Cpath fill='%230c4a6e' fill-opacity='1' d='M0,128L1440,32L1440,320L0,320Z'%3E%3C/path%3E%3C/svg%3E%0A");
      }
      /***************************************************
 * Generated by SVG Artista on 1/16/2022, 11:54:01 PM
 * MIT license (https://opensource.org/licenses/MIT)
 * W. https://svgartista.net
 **************************************************/

      .animateStroke {
        stroke-dashoffset: 85.66563415527344px;
        stroke-dasharray: 85.66563415527344px;
        animation: stroke 1s cubic-bezier(0.47, 0, 0.745, 0.715) forwards;
      }
      * {
        pointer-events: auto !important;
      }
      @keyframes stroke {
        100% {
          stroke-dashoffset: 0;
        }
      }
      * {
        outline: 0;
      }
      @media only screen and (max-width: 992px) {
        .hide-img {
          display: none !important;
        }
      }
      @media (prefers-color-scheme: dark) {
          html {
            background: #404040 !important;
          }
         nav {
          background: rgba(17, 24, 39, 0.9) !important;
        }
      }
    </style>
  </head>
  <body class="dark:bg-gray-900 dark:text-white hidden">
		<div class="fixed bottom-5 left-5 px-5 py-2 shadow-lg flex gap-3 rounded-full dark:bg-gray-800 bg-white dark:text-white text-md border dark:border-gray-600" id="cookiePopup" style="z-index:99999999!important;animation: d .2s forwards;">
		We use  &#127850
		<i class="cursor-pointer z-50 material-icons" onclick="this.parentElement.remove();localStorage.setItem('cookiePopup', 'true')">close</i>
	</div>
    <div class="bg-green-600 bg-gradient-to-r from-green-500 to-emerald-500">
      <div class="max-w-8xl mx-auto py-3 px-3 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between flex-wrap">
          <div class="w-0 flex-1 flex items-center">
            <span class="flex p-2 rounded-lg bg-green-700">
              <!-- Heroicon name: outline/speakerphone -->
              <svg
                class="h-6 w-6 text-white"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                aria-hidden="true"
              >
                <path
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="1.5"
                  d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z"
                />
              </svg>
            </span>
            <p class="ml-3 font-medium text-white truncate">
              <span class="md:hidden">Smartlist v4.5.3-alpha is here!</span>
              <span class="hidden md:inline">
                Introducing home profiles, lists, and recipes! We've improvised
                the design and security of our app
              </span>
            </p>
          </div>
          <div
            class="order-3 mt-2 flex-shrink-0 w-full sm:order-2 sm:mt-0 sm:w-auto"
          >
            <a
              href="<?=$_CONFIG->banner->buttonURL;?>"
              class="flex items-center @ripple justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-green-600 bg-white hover:bg-green-100 focus-visible:ring-2 hover:ring-none active:ring-none focus:ring-white matify:ripple"
            >
              Learn more
            </a>
          </div>
          <div class="order-2 flex-shrink-0 sm:order-3 sm:ml-3">
            <button
              type="button"
              class="@ripple -mr-1 matify:ripple flex p-2 rounded-md hover:bg-emerald-500 hover:ring-none active:ring-none focus:outline-none focus-visible:ring-2 matify:ripple@light focus:ring-white sm:-mr-2"
              onclick="this.parentElement.parentElement.parentElement.parentElement.remove()"
            >
              <span class="sr-only">Dismiss</span>
              <!-- Heroicon name: outline/x -->
              <i class="material-icons-round text-white">close</i>
            </button>
          </div>
        </div>
      </div>
    </div>
    <nav
      class="border-b text-gray-700 sticky top-0 flex items-center w-full px-4 py-2 h-20 z-50 dark:bg-gray-800 backdrop-blur-xl dark:border-gray-700"
      style="background: rgba(255, 255, 255, 0.7)"
    >
      <a
        href="/"
        class="text-gray-900 text-semibold rounded-lg focus-visible:ring ring-black px-3 hover:bg-gray-200 mr-2 inline-flex py-2 dark:text-gray-100 text-bold dark:focus-visible:ring-white dark:hover:bg-gray-600 dark:hover:text-white hover:ring-none"
        >Smartlist</a
      >
      <a
        href="/our-impact"
        class="rounded-lg hover:ring-none active:ring-none focus-visible:ring hidden ring-black px-3 hover:bg-gray-200 mr-2 lg:inline-flex py-2 dark:text-gray-400 dark:focus:ring-white dark:hover:bg-gray-600 hover:text-black dark:hover:text-white matify:ripple"
        >Our impact</a
      >
      <a
        href="/privacy"
        class="rounded-lg hover:ring-none active:ring-none focus-visible:ring ring-black px-3 hover:bg-gray-200 mr-2 lg:inline-flex py-2 dark:text-gray-400 dark:focus:ring-white dark:hover:bg-gray-600 hover:text-black dark:hover:text-white matify:ripple"
        >Privacy</a
      >
      <a
        href="//collaborate.smartlist.ga"
        class="rounded-lg hover:ring-none active:ring-none focus-visible:ring hidden ring-black px-3 hover:bg-gray-200 mr-2 lg:inline-flex py-2 dark:text-gray-400 dark:focus:ring-white dark:hover:bg-gray-600 hover:text-black dark:hover:text-white matify:ripple"
        >Collaborate</a
      >
      <a
        href="https://discord.gg/QDwxp7qrf2"
        class="rounded-lg hover:ring-none active:ring-none focus-visible:ring hidden ring-black px-3 hover:bg-gray-200 mr-2 lg:inline-flex py-2 dark:text-gray-400 dark:focus:ring-white dark:hover:bg-gray-600 hover:text-black dark:hover:text-white matify:ripple"
        >Discord</a
      >
      <a
        href="//community.smartlist.ga"
        class="rounded-lg hover:ring-none active:ring-none focus-visible:ring hidden ring-black px-3 hover:bg-gray-200 mr-2 lg:inline-flex py-2 dark:text-gray-400 dark:focus:ring-white dark:hover:bg-gray-600 hover:text-black dark:hover:text-white matify:ripple"
        >Community Forum</a
      >
      <a
        href="//team.smartlist.ga"
        class="rounded-lg hover:ring-none active:ring-none focus-visible:ring hidden ring-black px-3 hover:bg-gray-200 mr-2 lg:inline-flex py-2 dark:text-gray-400 dark:focus:ring-white dark:hover:bg-gray-600 hover:text-black dark:hover:text-white matify:ripple"
        >Our team</a
      >
      <button
        data-dropdown-toggle="dropdown"
        href="#"
        class="rounded-lg hover:ring-none active:ring-none focus-visible:ring hidden ring-black px-3 hover:bg-gray-200 mr-2 lg:inline-flex py-2 dark:text-gray-400 dark:focus:ring-white dark:hover:bg-gray-600 hover:text-black dark:hover:text-white matify:ripple"
      >
        Products <i class="material-icons ml-3">expand_more</i>
      </button>
			<button
        data-dropdown-toggle="dropdown_features"
        href="#"
        class="rounded-lg hover:ring-none active:ring-none focus-visible:ring hidden ring-black px-3 hover:bg-gray-200 mr-2 lg:inline-flex py-2 dark:text-gray-400 dark:focus:ring-white dark:hover:bg-gray-600 hover:text-black dark:hover:text-white matify:ripple"
      >
        Features <i class="material-icons ml-3">expand_more</i>
      </button>
      <a
        href="/login"
        class="rounded-lg hover:ring-none active:ring-none focus-visible:ring order-2 ml-auto bg-green-500 text-white ring-black px-3 hover:bg-green-800 inline-flex py-2 dark:bg-sky-900 matify:ripple@light matify:ripple"
      >
        <span class="lg:hidden md:hidden">Sign in</span>
        <span class="hide-on-med-and-down">Continue to my account</span>
        <i class="material-icons ml-2">chevron_right</i>
      </a>

      <div
        id="dropdown"
        class="hidden z-10 w-56 text-base list-none bg-white rounded divide-y divide-gray-100 shadow dark:bg-gray-700"
      >
        <ul class="py-1" aria-labelledby="dropdownButton">
          <li>
            <a
              href="/"
              class="block py-3 px-5 matify:ripple text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white"
            >
              <h5 class="text-lg">Smartlist</h5>
							<p class="text-gray-600 dark:text-gray-200">Home inventory and finance tracking</p>
            </a>
          </li>
          <li>
            <a
              href="//collaborate.smartlist.ga/about"
              class="block py-3 px-5 matify:ripple text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white"
            >
              <h5 class="text-lg">Smartlist Collaborate</h5>
							<p class="text-gray-600 dark:text-gray-200">Plan your events in real-time</p>
            </a>
          </li>
          <li>
            <a
              href="#"
              class="block py-3 px-5 matify:ripple text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white"
              >
								<span class="bg-blue-100 text-blue-800 text-sm font-medium mr-2 mt-2 px-2.5 py-0.5 rounded dark:bg-blue-200 dark:text-blue-800">Coming soon!</span>
								<h5 class="text-lg mt-1">Smartlist Parking</h5>
								<p class="text-gray-600 dark:text-gray-200">Locate your car with ease.</p>
							</a
            >
          </li>
          <li>
            <a
              href="/dashboard/#/recipes"
              class="block py-3 px-5 matify:ripple text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white"
              >
								<h5 class="text-lg">Smartlist Recipes</h5>
								<p class="text-gray-600 dark:text-gray-200">Home inventory and finance tracking</p>
							</a
            >
          </li>
        </ul>
      </div>




			<div
        id="dropdown_features"
        class="hidden z-10 w-96 p-2 text-base list-none bg-white rounded divide-y divide-gray-100 shadow-lg dark:bg-gray-700"
      >
        <ul class="py-1" aria-labelledby="dropdownButton">
          <li>
            <a href="/" class="block py-3 px-5 matify:ripple text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white" >Inventory</a>
          </li>
          <li>
            <a href="/" class="block py-3 px-5 matify:ripple text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white" > Finance manager </a>
          </li>
          <li>
						<a href="/" class="block py-3 px-5 matify:ripple text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white" > Finance lessons </a>
          </li>
          <li>
						<a href="/" class="block py-3 px-5 matify:ripple text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white" > Home maintenance </a>
          </li>
					<li>
						<a href="/" class="block py-3 px-5 matify:ripple text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white" > Lists </a>
          </li>
					<li>
						<a href="/" class="block py-3 px-5 matify:ripple text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white" > Shopping assistant </a>
          </li>
					<li>
						<a href="/" class="block py-3 px-5 matify:ripple text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white" > Inventory sync </a>
          </li>
					<li>
						<a href="/" class="block py-3 px-5 matify:ripple text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white" > Encryption </a>
          </li>
					<li>
						<a href="/" class="block py-3 px-5 matify:ripple text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white" > Reminders </a>
          </li>
					<li>
						<a href="/" class="block py-3 px-5 matify:ripple text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white" > Meal planning </a>
          </li>
        </ul>
      </div>
    </nav>

    <div class="w-11/12 p-4 mx-auto">
      <div id="scene" class="flex items-center gap-10 mt-10 h-96 w-full">
        <div data-depth="0.1" style="z-index: 1 !important">
          <h1 class="text-6xl mt-20 lg:text-7xl md:text-8xl mb-5" style="font-family: 'DM Serif Display', serif;">
            Financial struggle
            <span
						style="font-family: 'DM Serif Display', serif;"
              class="flex mt-2 text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-900"
              >ends here. For free.</span>
          </h1>
          <p class="dark:text-gray-300 mb-5 text-gray-800">
            Smartlist helps you keep track of what you have in your home and
            track your expenses for free
          </p>
          <div class="flex items-center" style="z-index: -1 !important">
            <a
              href="/signup"
              class="matify:ripple text-white bg-gradient-to-r from-green-400 via-green-500 to-green-600 hover:bg-gradient-to-br hover:ring-none active:ring-none focus-visible:ring-4 focus:ring-green-300 dark:focus:ring-green-800 shadow-lg shadow-green-200 dark:shadow-lg inline-flex items-center gap-3 dark:shadow-green-900 font-medium rounded-lg text-md px-6 py-4 text-center mr-2 mb-2"
              >
							Get started
							</a>
            <button
              onclick="window.open('https://www.youtube.com/watch?v=C5a72RRzOoc')"
              type="button"
              class="matify:ripple text-gray-900 bg-gradient-to-r from-teal-200 to-lime-200 hover:bg-gradient-to-l hover:from-teal-200 hover:to-lime-200 hover:ring-none active:ring-none focus-visible:ring-4 focus:ring-lime-200 dark:focus:ring-teal-700 font-medium rounded-lg text-md px-6 py-4 inline-flex items-center gap-3 text-center mr-2 mb-2"
            >
              <i class="material-icons">play_circle</i> Watch the video
            </button>
          </div>
          <!-- <a href="https://www.producthunt.com/posts/smartlist?utm_source=badge-featured&utm_medium=badge&utm_souce=badge-smartlist" target="_blank" class="inline-block mb-4"><img loading="lazy" src="https://api.producthunt.com/widgets/embed-image/v1/featured.svg?post_id=321053&theme=dark" alt="Smartlist - Smart and easy home inventory and finance management. | Product Hunt" style="width: 250px; height: 54px;" width="250" height="54" /></a> -->
        </div>
        <div
          data-depth="0.2"
          class="top-0 right-0 text-right float-right order-2 ml-auto p-10 hidden lg:flex md:flex hide-img"
        >
          <img
            loading="lazy"
            src="https://i.ibb.co/nD5N5Vp/business-3d-young-black-man-jumping.png"
            style="max-height: 500px"
            class="float-right m-auto rounded-2xl blur-xl"
            onload="setTimeout(()=>this.classList.remove('blur-xl'),200)"
            draggable="false"
          />
        </div>
      </div>

      <div class="mt-20 pt-20">
				<h1 class="my-10 text-3xl font-semibold text-center text-gray-700 lg:text-4xl dark:text-white">Make more from <br> what you  <span class="text-emerald-500">earn</span></h1>

        <div
          class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-5"
        >
          <div
            class="overflow-hidden rounded-lg text-center justify-center relative bg-gray-200 p-3 dark:bg-gray-700"
          >
            <img
              loading="lazy"
              class="rounded-lg blur-xl"
              onload="setTimeout(()=>this.classList.remove('blur-xl'),200)"
              src="https://i.ibb.co/cCbP3v5/abstract-list-is-empty.png"
            />
            <div class="px-5 py-7">
              <h3 class="text-xl">Track what's inside your home</h3>
            </div>
          </div>
          <div
            class="overflow-hidden rounded-lg text-center justify-center relative bg-gray-200 p-3 dark:bg-gray-700"
          >
            <img
              loading="lazy"
              class="rounded-lg blur-xl"
              onload="setTimeout(()=>this.classList.remove('blur-xl'),200)"
              src="https://i.ibb.co/6B87qH9/abstract-1398.png"
            />
            <div class="px-5 py-7">
              <h3 class="text-xl">Plan what you'll cook</h3>
            </div>
          </div>
          <div
            class="overflow-hidden rounded-lg text-center justify-center relative bg-gray-200 p-3 dark:bg-gray-700"
          >
            <img
              loading="lazy"
              class="rounded-lg blur-xl"
              onload="setTimeout(()=>this.classList.remove('blur-xl'),200)"
              src="https://i.ibb.co/HXzHtj2/abstract-mobile-payment.png"
            />
            <div class="px-5 py-7">
              <h3 class="text-xl">Learn finance tips and tricks</h3>
            </div>
          </div>
          <div
            class="overflow-hidden rounded-lg text-center justify-center relative bg-gray-200 p-3 dark:bg-gray-700"
          >
            <img
              loading="lazy"
              class="rounded-lg blur-xl"
              onload="setTimeout(()=>this.classList.remove('blur-xl'),200)"
              src="https://i.ibb.co/SQJxH03/abstract-expense-tracking.png"
            />
            <div class="px-5 py-7">
              <h3 class="text-xl">Know where your money's going</h3>
            </div>
          </div>
          <div
            class="overflow-hidden rounded-lg text-center justify-center relative bg-gray-200 p-3 dark:bg-gray-700"
          >
            <img
              class="rounded-lg blur-xl"
              onload="setTimeout(()=>this.classList.remove('blur-xl'),200)"
              src="https://i.ibb.co/G21GFKG/abstract-done-1.png"
            />
            <div class="px-5 py-7">
              <h3 class="text-xl">Create and edit custom lists</h3>
            </div>
          </div>
          <div
            class="overflow-hidden rounded-lg text-center justify-center relative bg-gray-200 p-3 dark:bg-gray-700"
          >
            <img
              loading="lazy"
              class="rounded-lg blur-xl"
              onload="setTimeout(()=>this.classList.remove('blur-xl'),200)"
              src="https://i.ibb.co/YbzHVFM/abstract-coffee-break.png"
            />
            <div class="px-5 py-7">
              <h3 class="text-xl">Get maintenance reminders</h3>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="overflow-hidden dark:text-white p-4">
      <div class="container mx-auto px-10 py-10 lg:py-25 bg-gray-100 dark:bg-gray-800 rounded-xl">
        <div class="grid grid-cols-1 lg:grid-cols-2">
          <div class="pt-10 pb-10">
							<h1 class="text-3xl font-semibold text-gray-800 lg:text-4xl dark:text-white">Smart and <span class="text-emerald-500">intuitive</span></h1>
            <p class="my-2 wow fadeInUp opacity-75">
              Our app is designed for anyone and everyone to use. Accessible to
              all.
            </p>
            <p class="mb-4 wow fadeInUp dark:text-white opacity-50">
              What's your favorite color?
            </p>
            <a
              href="javascript:void(0)"
              class="matify:ripple focus-visible:ring-2 focus:ring-black w-10 h-10 rounded-xl inline-block focus:ring-offset-2 mr-2 wow fadeInUp hover:shadow-lg"
              style="background: #41308a"
              onclick="document.getElementById('i1').src='<?=$_CONFIG->homePage->themeColorImages[0]->url;?>'"
            ></a>
            <a
              href="javascript:void(0)"
              class="matify:ripple focus-visible:ring-2 focus:ring-black w-10 h-10 rounded-xl inline-block focus:ring-offset-2 mr-2 wow fadeInUp hover:shadow-lg"
              style="background: #6200ea"
              onclick="document.getElementById('i1').src='<?=$_CONFIG->homePage->themeColorImages[1]->url;?>'"
            ></a>
            <a
              href="javascript:void(0)"
              class="matify:ripple focus-visible:ring-2 focus:ring-black w-10 h-10 rounded-xl inline-block focus:ring-offset-2 mr-2 wow fadeInUp hover:shadow-lg"
              style="background: #b00020"
              onclick="document.getElementById('i1').src='<?=$_CONFIG->homePage->themeColorImages[2]->url;?>'"
            ></a>
            <a
              href="javascript:void(0)"
              class="matify:ripple focus-visible:ring-2 focus:ring-black w-10 h-10 rounded-xl inline-block focus:ring-offset-2 mr-2 wow fadeInUp hover:shadow-lg"
              style="background: #00695c"
              onclick="document.getElementById('i1').src='<?=$_CONFIG->homePage->themeColorImages[3]->url;?>'"
            ></a>
            <a
              href="javascript:void(0)"
              class="matify:ripple focus-visible:ring-2 focus:ring-black w-10 h-10 rounded-xl inline-block focus:ring-offset-2 mr-2 wow fadeInUp hover:shadow-lg"
              style="background: #00838f"
              onclick="document.getElementById('i1').src='<?=$_CONFIG->homePage->themeColorImages[4]->url;?>'"
            ></a>
            <a
              href="javascript:void(0)"
              class="matify:ripple focus-visible:ring-2 focus:ring-black w-10 h-10 rounded-xl inline-block focus:ring-offset-2 mr-2 wow fadeInUp hover:shadow-lg"
              style="background: #0277bd"
              onclick="document.getElementById('i1').src='<?=$_CONFIG->homePage->themeColorImages[5]->url;?>'"
            ></a>
            <a
              href="javascript:void(0)"
              class="matify:ripple focus-visible:ring-2 focus:ring-black w-10 h-10 rounded-xl inline-block focus:ring-offset-2 mr-2 wow fadeInUp hover:shadow-lg"
              style="background: #2e7d32"
              onclick="document.getElementById('i1').src='<?=$_CONFIG->homePage->themeColorImages[6]->url;?>'"
            ></a>
            <a
              href="javascript:void(0)"
              class="matify:ripple focus-visible:ring-2 focus:ring-black w-10 h-10 rounded-xl inline-block focus:ring-offset-2 mr-2 wow fadeInUp hover:shadow-lg"
              style="background: #ef6c00"
              onclick="document.getElementById('i1').src='<?=$_CONFIG->homePage->themeColorImages[7]->url;?>'"
            ></a>
            <a
              href="javascript:void(0)"
              class="matify:ripple focus-visible:ring-2 focus:ring-black w-10 h-10 rounded-xl inline-block focus:ring-offset-2 mr-2 wow fadeInUp hover:shadow-lg"
              style="background: #ad1457"
              onclick="document.getElementById('i1').src='<?=$_CONFIG->homePage->themeColorImages[8]->url;?>'"
            ></a>
            <a
              href="javascript:void(0)"
              class="matify:ripple focus-visible:ring-2 focus:ring-black w-10 h-10 rounded-xl inline-block focus:ring-offset-2 mr-2 wow fadeInUp hover:shadow-lg"
              style="background: #37474f"
              onclick="document.getElementById('i1').src='<?=$_CONFIG->homePage->themeColorImages[9]->url;?>'"
            ></a>
          </div>
          <div>
            <img
              onload="setTimeout(()=>this.classList.remove('blur-xl'),200)"
              loading="lazy"
              src="https://i.ibb.co/PtGmgmd/image.png"
              id="i1"
              alt=""
              class="shadow-md rounded-md wow fadeInRight w-full blur-xl"
            />
          </div>
        </div>
      </div>
    </div>


		<section class="bg-white dark:bg-gray-900 wow fadeIn">
			<div class="container px-6 py-20 mx-auto">
					<h1 class="text-3xl font-semibold text-center text-gray-800 lg:text-4xl dark:text-white">Your privacy <br> is our  <span class="text-emerald-500">first priority</span></h1>
					
					<div class="grid grid-cols-1 gap-8 mt-8 xl:mt-12 xl:gap-16 md:grid-cols-2 xl:grid-cols-3">
							<div class="flex flex-col items-center p-6 space-y-3 text-center bg-gray-100 rounded-xl dark:bg-gray-800">
									<span class="w-16 h-16 flex items-center justify-center p-3 text-emerald-500 bg-emerald-100 rounded-full dark:text-white dark:bg-emerald-500">
										<i class="material-icons">password</i>	
									</span>
									<h1 class="text-2xl font-semibold text-gray-700 capitalize dark:text-white">Argon2 hashing</h1>
									<p class="text-gray-500 dark:text-gray-300">
											Your account details are hashed using the Argon2 algorithm
									</p>
							</div>

							<div class="flex flex-col items-center p-6 space-y-3 text-center bg-gray-100 rounded-xl dark:bg-gray-800">
									<span class="w-16 h-16 flex items-center justify-center  p-3 text-emerald-500 bg-emerald-100 rounded-full dark:text-white dark:bg-emerald-500">
										<i class="material-icons">enhanced_encryption</i>	
									</span>

									<h1 class="text-2xl font-semibold text-gray-700 capitalize dark:text-white">AES-256 encryption</h1>

									<p class="text-gray-500 dark:text-gray-300">
											Your account's safely stored in our servers with zero-access encryption.
									</p>
							</div>

							<div class="flex flex-col items-center p-6 space-y-3 text-center bg-gray-100 rounded-xl dark:bg-gray-800">
										<span class="w-16 h-16 flex items-center justify-center  p-3 text-emerald-500 bg-emerald-100 rounded-full dark:text-white dark:bg-emerald-500">
										<i class="material-icons">vpn_lock</i>	
									</span>

									<h1 class="text-2xl font-semibold text-gray-700 capitalize dark:text-white">VPN</h1>

									<p class="text-gray-500 dark:text-gray-300">
											We use a VPN with an end-to-end encryption and secure tunneling.
									</p>
							</div>
					</div>
			</div>
		</section>

    <div class="grid grid-cols-1">
      <div
        class="bg-rose-900 text-white rounded-none py-10 mx-auto px-10 py-20 lg:py-20 w-full"
      >
        <h2 class="text-4xl mt-2">Introducing Smartlist collaborate</h2>
        <h3 class="text-2xl mt-2">Collaborate on your events and parties</h3>
        <p class="mt-1">
          Smartlist collaborate helps you plan your events in advance. You'll be
          able to plan your menu, manage guest lists, items, and more.
        </p>
        <a
          href="//collaborate.smartlist.ga"
          target="_blank"
          class="bg-rose-800 hover:bg-rose-700 rounded-lg mt-5 focus-visible:ring-2 focus:ring-rose-700 py-4 px-5 inline-block focus:ring-offset-2 matify:ripple matify:ripple@light"
          >Join my event</a
        >
        <a
          href="//collaborate.smartlist.ga/about"
          target="_blank"
          class="bg-rose-800 hover:bg-rose-700 rounded-lg mt-5 focus-visible:ring-2 focus:ring-rose-700 py-4 px-5 inline-block focus:ring-offset-2 matify:ripple matify:ripple@light"
          >Learn more</a
        >
      </div>
    </div>

    <div class="w-11/12 mx-auto">
      <center>
						<h1 class="my-10 text-3xl font-semibold text-center text-gray-800 lg:text-4xl dark:text-white">Developer resources</h1>
      </center>
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-5 md:grid-cols-2">
        <div>
          <h2 class="text-emerald-900 dark:text-emerald-400 text-3xl my-4">
            Integrate our API seamlessly with your app
          </h2>
          <p class="my-3 text-gray-500">Get a summary of data from us</p>
          <code
            class="text-sm p-4 rounded-xl text-white border dark:border-gray-800 border-gray-900 flex my-2 shadow-lg"
            style="background: #161b1d"
          >
            <pre
              class="prettyprint"
              style="
                font-family: 'Source Code Pro', monospace !important;
                overflow-x: scroll;
              "
            >
const Smartlist = require("smartlist-api");
let api = new Smartlist(process.env.API_KEY);
api.getFinances().then(res => console.log(res))

// Result:
{
	"total": 2725,
	"breakdown": {
		"groceryShopping": 741,
		"clothesShopping": 438,
		"maintenance": 957,
		"other": 394,
		"holidays": 195,
	}	
}
</pre
            >
          </code>
        </div>

        <div>
          <h2 class="text-emerald-900 dark:text-emerald-400 text-3xl my-4">
            Create an oAuth API
          </h2>
          <p class="my-3 text-gray-500">Authenticate your users with our app</p>
          <code
            class="text-sm p-4 rounded-lg text-white border dark:border-gray-800 border-gray-900 flex my-2 shadow-xl"
            style="background: #161b1d; overflow-x: scroll"
          >
            <pre
              class="prettyprint"
              style="font-family: 'Source Code Pro', monospace !important"
            >
<!-- &lt;script src=&quot;https://cdn.jsdelivr.net/gh/Smartlist-App/Smartlist-Login-Button@2.0.0/app.min.js&quot; async&gt;&lt;/script&gt; -->&lt;div id=&quot;loginBTN&quot;&gt;&lt;/div&gt;
&lt;script&gt;
const button = new SmartlistApiButton(document.getElementById(&#39;loginBTN&#39;), {
		appId: &quot;YOUR_APP_ID&quot;,
		popup: true,
		callback() {
			console.log(&quot;Closed popup&quot;)
		}
	})
&lt;/script&gt;
</pre>
          </code>
        </div>

        <div></div>
      </div>
    </div>

    <!-- Begin CTA -->
    <!-- This example requires Tailwind CSS v2.0+ -->

    <div class="bg-gray-50 dark:bg-transparent">
      <div
        class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:py-16 lg:px-8 lg:flex lg:items-center lg:justify-between"
      >
        <h2
          class="text-3xl font-extrabold tracking-tight text-gray-900 sm:text-4xl dark:text-gray-200"
        >
          <span class="block">Ready to start saving money?</span>
          <span class="block text-emerald-600">Join now - It's free!</span>
        </h2>
        <div class="mt-8 flex lg:mt-0 lg:flex-shrink-0">
          <div class="matify:ripple inline-flex rounded-md shadow">
            <a
              href="#"
              class="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-emerald-600 focus:ring-4 ring-emerald-400 outline-none hover:bg-emerald-700"
            >
              Get started
            </a>
          </div>
          <div class="ml-3 inline-flex rounded-md shadow">
            <a
              href="https://www.producthunt.com/posts/smartlist?utm_source=badge-featured&utm_medium=badge&utm_souce=badge-smartlist"
              class="matify:ripple inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-emerald-600 focus:ring-4 ring-emerald-400 outline-none bg-white hover:bg-emerald-50 focus:bg-emerald-100 dark:bg-gray-900 dark:hover:bg-gray-800 dark:focus:bg-gray-800"
            >
              Learn more
            </a>
          </div>
        </div>
      </div>
    </div>

    <!-- end CTA -->

    <div class="bg w-full h-36 bg-cover"></div>
    <footer class="bg-sky-900 bg-gradient-to-b from-sky-900 to-sky-800">
      <div class="container px-6 pb-8 pt-3 mx-auto">
        <div class="grid gap-8 grid-cols-1 lg:grid-cols-3">
          <div>
            <div class="text-2xl font-medium text-gray-100">Smartlist</div>

            <a
              href="#"
              class="matify:ripple block mt-3 text-sm font-medium text-white opacity-50"
            >
              Helping people overcome financial stress
            </a>
            <a
              href="https://www.producthunt.com/posts/smartlist?utm_source=badge-featured&utm_medium=badge&utm_souce=badge-smartlist"
              class="mt-2 matify:ripple overflow-hidden rounded-2xl"
              style="
                overflow: hidden !important;
                display: inline-block;
                margin-top: 10px !important;
              "
              target="_blank"
              ><img
                onload="setTimeout(()=>this.classList.remove('blur-xl'),200)"
                src="https://api.producthunt.com/widgets/embed-image/v1/featured.svg?post_id=321053&theme=dark"
                alt="Smartlist - Smart and easy home inventory and finance management. | Product Hunt"
                style="width: 250px; height: 54px"
                width="250"
                height="54"
                class="blur-xl"
            /></a>
          </div>

          <div>
            <div class="text-xs font-medium text-gray-400 uppercase">
              Company
            </div>

            <a
              href="//team.smartlist.ga"
              class="block mt-5 text-sm font-medium text-gray-100 duration-700 dark:text-gray-300 hover:text-gray-400 dark:hover:text-gray-200 hover:underline"
            >
              Our team
            </a>
            <a
              href="/join"
              class="block mt-3 text-sm font-medium text-gray-100 duration-700 dark:text-gray-300 hover:text-gray-400 dark:hover:text-gray-200 hover:underline"
            >
              Join us
            </a>

            <a
              href="https://github.com/Smartlist-App/Smartlist"
              class="block mt-3 text-sm font-medium text-gray-100 duration-700 dark:text-gray-300 hover:text-gray-400 dark:hover:text-gray-200 hover:underline"
            >
              Organization
            </a>

            <a
              href="https://github.com/Smartlist-App/Smartlist"
              class="block mt-3 text-sm font-medium text-gray-100 duration-700 dark:text-gray-300 hover:text-gray-400 dark:hover:text-gray-200 hover:underline"
            >
              Terms of Service
            </a>
            <a
              href="https://support.smartlist.ga/#/legal/privacy-policy"
              class="block mt-3 text-sm font-medium text-gray-100 duration-700 dark:text-gray-300 hover:text-gray-400 dark:hover:text-gray-200 hover:underline"
            >
              Privacy Policy
            </a>
          </div>

          <div>
            <div class="text-xs font-medium text-gray-400 uppercase">Links</div>

            <a
              href="https://discord.gg/QDwxp7qrf2"
              class="block mt-5 text-sm font-medium text-gray-100 duration-700 dark:text-gray-300 hover:text-gray-400 dark:hover:text-gray-200 hover:underline"
            >
              Discord server
            </a>
            <a
              href="//community.smartlist.ga"
              class="block mt-3 text-sm font-medium text-gray-100 duration-700 dark:text-gray-300 hover:text-gray-400 dark:hover:text-gray-200 hover:underline"
            >
              Community Forum
            </a>
            <a
              href="//events.smartlist.ga"
              class="block mt-3 text-sm font-medium text-gray-100 duration-700 dark:text-gray-300 hover:text-gray-400 dark:hover:text-gray-200 hover:underline"
            >
              Smartlist Events
            </a>
            <a
              href="//support.smartlist.ga"
              class="block mt-3 text-sm font-medium text-gray-100 duration-700 dark:text-gray-300 hover:text-gray-400 dark:hover:text-gray-200 hover:underline"
            >
              Knowledge base
            </a>
            <a
              href="https://github.com/Smartlist-App/Smartlist"
              class="block mt-3 text-sm font-medium text-gray-100 duration-700 dark:text-gray-300 hover:text-gray-400 dark:hover:text-gray-200 hover:underline"
            >
              View on GitHub
            </a>
            <a
              href="/our-impact"
              class="block mt-3 text-sm font-medium text-gray-100 duration-700 dark:text-gray-300 hover:text-gray-400 dark:hover:text-gray-200 hover:underline"
            >
              Our Impact
            </a>
            <a
              href="/privacy"
              class="block mt-3 text-sm font-medium text-gray-100 duration-700 dark:text-gray-300 hover:text-gray-400 dark:hover:text-gray-200 hover:underline"
            >
              Privacy
            </a>
          </div>
        </div>

        <hr class="my-10 border-gray-200 opacity-25 dark:border-gray-700" />

        <div class="sm:flex sm:items-center sm:justify-between">
          <p class="text-sm text-gray-200 flex items-center">
            <span class="material-icons-outlined mr-2">copyright</span> Copyright <span class="ml-1" id="year"></span>. All Rights Reserved.
          </p>

          <div class="flex mt-3 -mx-2 sm:mt-0">
            <a
              href="#"
              class="mx-2 text-gray-200 hover:text-gray-300 dark:hover:text-gray-300"
              aria-label="Reddit"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                class="h-6 w-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                width="24"
                height="24"
              >
                <path
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="2"
                  d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"
                  class="animateStroke wow"
                ></path>
              </svg>
            </a>
            <a
              href="https://github.com/Smartlist-App/Smartlist"
              class="mx-2 text-gray-200 hover:text-gray-300 dark:hover:text-gray-300"
              aria-label="Github"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                class="h-6 w-6"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                width="24"
                height="24"
              >
                <path
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="2"
                  d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"
                  class="animateStroke wow"
                ></path>
              </svg>
            </a>
          </div>
        </div>
      </div>
    </footer>

    <script>
      if (window.innerWidth > 992) {
        var scene = document.getElementById("scene");
        var parallaxInstance = new Parallax(scene, {
          relativeInput: true,
        });
      }
      new WOW().init();
      setInterval(() => {
        document.getElementById("year").innerHTML = new Date().getFullYear();
      }, 100);

    if('cookiePopup' in localStorage) {
        document.getElementById("cookiePopup").remove()
    }
    document.body.classList.remove("hidden")
    </script>
  </body>
</html>