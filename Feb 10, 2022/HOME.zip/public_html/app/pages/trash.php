<?php
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.smartlist.ga/v2/trash/',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => 30,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => 'token=2d8a0db9ca24b84453d7e12368cb9d18c5397b1cf6d96a8d2381dcf448ca60caf9cc28e8f0d41c559cb9df0daf16f37e5440ceed52203b860e9b4950d42d5c90f8a84474b8f5fd4b0599a2fe66d2fc4f86ceaad7e6ef44b503e10d28eb0b60af8fc86168154cb58cdcad0f893c2f61cc21030036217e702250cd6cfd66060e58349c1c8b79dd5427f62808e8e978533b73159c27b72d0692218b54b7eca9dd63fd266505d29d634e938528ac1118d3616ce47ce4b458d1747482e36d682b4f30dcf2c00ee59b772aff0ad4d77130778f1e9da25cc5b2cb8ec8a4840ca3e3c558db5ac0e87187d167e32eed1dfd49d27b4a0b9a59e3d40edf67b35bf2e6633038e770837e702ac2b73c0ae0e5109f4738ebf0f45741d05dd3866cfbbdfd6a33447c15bdf5f38d3b181315b5f8&room=kitchen',
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/x-www-form-urlencoded'
  ),
));
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($curl, CURLOPT_POSTFIELDS, 'token='.$_COOKIE['UserToken']);


$data = json_decode(curl_exec($curl));

curl_close($curl);
?>

<div class="container">
     <?php if(count($data->data) === 0) {?> 
        <div class="center grey-text valign-wrapper" style="height:calc(100vh - 100px);flex-direction:column;align-items:center;justify-content:center">
            <h3><i class="material-icons medium">celebration</i></h3>
            <h5>No items in trash!</h5>
        </div>
    <?php } else { ?>
    <h5 class="my-5">Trash</h5>
    <a class="btn red lighten-5 black-text btn-rounded z-depth-0 material-ripple" onclick="deleteItem(-1)">Empty trash</a>
    <?php } ?>
    <div class="grid">
        <?php foreach($data->data as $res) {?>
            <div class="grid-item card card-panel z-depth-0 card-rounded card-border">
                <p class="my-1"><?=$res->title;?></p>
                <p class="my-1 grey-text text-darken-2"><?=$res->amount?></p>
                <p class="my-1 grey-text text-darken-2">Room: <?=$res->room?></p>
                <button onclick="restoreItem(this, <?=$res->id?>)" class="btn btn-rounded z-depth-0 red black-text lighten-5 material-ripple my-2 mr-2">Restore</button>
                <button onclick="deleteItem(this, <?=$res->id?>)" class="btn btn-rounded z-depth-0 red darken-3 material-ripple material-ripple@light my-2 mr-2">Delete</button>
            </div>
        <?php } ?>
    </div>
</div>
<div id="delete_modal_forever" class="modal-rounded modal modal-center bg-light">
    <div class="modal-content">
        <h5>Delete?</h5>
        <p class="grey-text text-darken-2 dark-text-white">This action is irreversible! </p>
        <div class="right-align mt-5">
        <button class="btn-rounded modal-close btn z-depth-0 dark-text-white transparent black-text material-ripple">Cancel</button>
        <button id="delete_ok" onclick="" class="btn-rounded dark-text-white btn z-depth-0 transparent material-ripple red-text text-darken-3">Delete</button>
    </div>
</div>
<script>
var elem = document.querySelector('.grid');
var msnry = new Masonry( elem, {
  itemSelector: '.grid-item',
  columnWidth: 200
})

var msnry = new Masonry( '.grid');
M.Modal.init(document.querySelector("#delete_modal_forever"), {
    onOpenStart: () => changeThemeColor('#7a7a7a'),
    onCloseStart: () => changeThemeColor('default'),
});
function deleteItem(el, id) {
    M.Modal.getInstance(document.querySelector("#delete_modal_forever")).open()
    new Promise((resolve, reject) => {
        document.getElementById("delete_ok").addEventListener("click", () => {
            document.getElementById("delete_ok").innerHTML = `<svg width="15" height="15" viewBox="0 0 38 38" xmlns="http://www.w3.org/2000/svg" stroke="#000"> <g fill="none" fill-rule="evenodd"> <g transform="translate(1 1)" stroke-width="2"> <circle stroke-opacity=".1" cx="18" cy="18" r="18"/> <path d="M36 18c0-9.94-8.06-18-18-18"> <animateTransform attributeName="transform" type="rotate" from="0 18 18" to="360 18 18" dur=".8s" repeatCount="indefinite"/> </path> </g> </g> </svg>`
            resolve(true);
        })
    }).then(d => {
       
        fetch('https://api.smartlist.ga/v2/items/delete/', {
            method: "POST",
            body: `id=${id}&token=${getCookie("UserToken")}&date=${moment().format('MMMM D YYYY [at] h:mm A')}&forever`,
            headers: { "Content-Type": "application/x-www-form-urlencoded" }
        })
        .then(res => {
            el.parentElement.remove();
            document.getElementById("delete_ok").innerHTML = "Delete";
            window.msnry.reloadItems();
            window.msnry.layout();
            M.Modal.getInstance(document.querySelector("#delete_modal_forever")).close()
        })
    })
}
function restoreItem(el,id) {
   fetch('https://api.smartlist.ga/v2/items/delete/', {
        method: "POST",
        body: `id=${id}&token=${getCookie("UserToken")}&date=${moment().format('MMMM D YYYY [at] h:mm A')}`,
        headers: { "Content-Type": "application/x-www-form-urlencoded" }
    })
    .then(res => {
        el.parentElement.remove();
        window.msnry.reloadItems();
        window.msnry.layout();
    })
}
</script>