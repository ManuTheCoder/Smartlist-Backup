<?php
ini_set("display_errors", 1);
if (!defined('CURL_HTTP_VERSION_3')) {
    define('CURL_HTTP_VERSION_3', 30);
}
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.smartlist.ga/v2/items/list/',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_3,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => 'token='.$_COOKIE['UserToken'],
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/x-www-form-urlencoded'
  ),
));
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($curl, CURLOPT_POSTFIELDS, 'token='.$_COOKIE['UserToken']."&room=".$_GET['room']);

$items = json_decode(curl_exec($curl))->data;

$suggestions = [];
switch($_GET['room']) {
    case "kitchen": $suggestions = ["Fridge", "Sink", "Oven", "Microwave", "Tomatoes", "Potatoes", "Salt", "Pepper", "Coffee maker", "Paper towel", "Kitchen timer", "Spinach", "Lettuce", "Yogurt", "Soap", "Dishwasher", "Dishwashing liquid", "Dish soap", "Forks", "Spoons", "Knives", "Ketchup", "Mustard", "Flour"]; break;
    case "garage": $suggestions = ["Car", "Wrench", "Hammer", "Nails", "Saw", "Electric drill", "Batteries", "Screwdrivers"]; break;
    case "bedroom": $suggestions = ["Nightstand", "Pillow", "Pillowcase", "Blanket", "Lamp", "Alarm clock", "Desk", "Wall painting"]; break;
    case "bathroom": $suggestions = ["Hand soap", "Shaver", "Deodorant", "Perfume", "Hair brush", "Mirror", "Bath towels", "Washcloths", "Toothbrush", "Toothpaste", "Dental flosses", "Shaving cream", "Sink", "Bathtub"]; break;
    case "living": $suggestions = ["Couch", "Lamp", "Coffee table", "Wall painting", "TV", "Speaker", "Sofa", "Cushion", "End table", "Remote", "Fan", "TV stand"]; break;
    case "dining": $suggestions = ["Dining table", "Dining chairs", "Platters", "China cabinet", "Table linens", "Silverware", "Cups"]; break;
    case "laundry": $suggestions = ["Washing machine", "Dryer", "Laundry basket", "Laundry supplies", "Iron", "Iron board", "Hanger", "Laundry sheets"]; break;
    case "storage": $suggestions = ["Masks", "Face shields", "Clorox wipes", "Lysol"]; break;
}

function checkIfItemExists($haystack, $needle) {
    $found = false;
    foreach($haystack as $item) {
        if(strtolower($item->title) == strtolower($needle)) {
            $found = true;
            break;
        }
    }
    return $found;
}
foreach($suggestions as $k=>$chip) {
    if(checkIfItemExists($items, $chip)) {
        unset($suggestions[$k]);
    }
}
?>
<div style="padding:20px;">
<div class="orange dark-darken-5 lighten-5" style="padding:28px;border-radius:28px;margin:10px;width:calc(100% - 20px)">
    <h5 class="orange-text dark-text-white text-darken-5 my-4" style="display:flex;align-items:center"><i class="material-icons left">auto_awesome</i>Suggested</h5>
    <div class="chip-suggestions suggested" style="border:0!important;white-space:nowrap;overflow-x:scroll">
        <?php foreach($suggestions as $chip) {?>
        <div onclick="addItem('<?=$_GET['room']?>');document.getElementById('add.item.form.name').value=this.innerText;setTimeout(()=>document.getElementById('add.item.form.qty').focus(),300)" class="chip orange dark-darken-4 lighten-4 black-text material-ripple m-2" style="cursor:pointer"><?=$chip;?></div>
        <?php } ?>
    </div>
    </div>
     <?php if(count($items) === 0) {?>
        <div class="center mt-20 card z-depth-0 card-rounded card-panel mx-auto" style="padding: 100px 10px; background:rgba(200,200,200,.3);width:calc(100% - 20px)">
            <h5>No items yet...</h5>
            <p class="grey-text text-darken-2 dark-text-white">Hit the <i class="material-icons mx-2" style="vertical-align:middle">edit</i> button to create an item</p>
        </div>
    <?php } ?>
    <div style="margin:10px;width:calc(100% - 20px);text-align:right" class="my-4 <?=(count($items) === 0?'hide':'')?>">
        <button data-target="filter" id="filterTrigger" class="dropdown-trigger btn red-text text-darken-4 red lighten-5 btn-rounded z-depth-0 material-ripple dark-red-4"><i class="material-icons left">filter_list</i> Sort by</button>
        <ul id="filter" class="dropdown-content">
            <li><a onclick="sortList('.grid', '.grid-item-3', false,false)">A-Z</a></li>
            <li><a onclick="sortList('.grid', '.grid-item-3', true,false)">Z-A</a></li>
            <li><a onclick="sortList('.grid', '.grid-item-3', true,true)">Last updated</a></li>
        </ul>
    </div>
   
    <div class="grid">
        <?php foreach($items as $item) {?>
            <div
                class="grid-item-3 card card-border card-rounded z-depth-0 material-ripple card-panel <?=intval($item->star) == 1 ? 'starred': ''?>"
                data-id="<?=intval($item->id)?>"
                data-star="<?=intval($item->star)?>"
                data-lastUpdated="<?=htmlspecialchars($item->lastUpdated)?>"
                data-sync="<?=htmlspecialchars($item->sync)?>"
                data-room="<?=htmlspecialchars($_GET['room'])?>"
                data-categories="<?=htmlspecialchars($item->categories)?>"
                style="cursor:pointer"
                onclick="item(this)">
                <h5 class="field my-4" style="max-width:20vw;"><?=htmlspecialchars($item->title)?></h5>
                <span class="field grey-text text-darken-2" style="max-width:20vw;"><?php if(empty($item->amount)) {?><span class="empty"></span><?php } ?><?=htmlspecialchars($item->amount)?></span>
                <span class="date hide"><?=htmlspecialchars($item->lastUpdated);?></span>
                <div class="mt-2"><?php 
                $d = explode(",", $item->categories); 
                if(!empty($d) && $item->categories !== "No Category Specified") {
                foreach($d as $category){
                    if(!empty($category)) {
                ?>
                <div class="chip chip-border"><?=htmlspecialchars($category);?></div>
                <?php } } } ?>
                </div>
            </div>
        <?php
        }?>
    </div>
</div>
<script>
   
var elem = document.querySelector('.grid');
window.msnry = new Masonry( elem, {
  // options
  itemSelector: '.grid-item',
  columnWidth: 200
});

// element argument can be a selector string
//   for an individual element
window.msnry = new Masonry( '.grid', {
  // options
});
    function sortList(a,b,reverse,date) {
    var container = document.querySelector(a),
        columns = container.querySelectorAll(b);

    if (columns.length) {
      columns = Array.from(columns); // or [].slice.apply(columns) if Array.from() is not available

      columns.sort(function(leftColumn, rightColumn) {
        var leftTitle = leftColumn.textContent;
        var rightTitle = rightColumn.textContent;

        if(date === true ) {
            leftTitle = leftColumn.querySelector('.date').textContent
            rightTitle = rightColumn.querySelector('.date').textContent
        }

        return leftTitle.localeCompare(rightTitle);
      });

      if(reverse) {
          columns.reverse().forEach(function(column) {
        container.appendChild(column);
      });
      }
      else {
          columns.forEach(function(column) {
        container.appendChild(column);
      });
      }
       window.msnry.reloadItems();
       window.msnry.layout();
    }
  }
  M.Dropdown.init(document.getElementById("filterTrigger"), {
      inDuration: (window.innerWidth > 992 ? 0 : .5),
      outDuration: (window.innerWidth > 992 ? 0 : .5),
      constrainWidth: false
  })
</script>