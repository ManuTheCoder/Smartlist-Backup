<?php
ini_set("display_errors", 1);
define("cardCount", 10);
$db = json_decode(file_get_contents("maintenance-db.json"));
function shuffle_assoc($list) {
	if (!is_array($list)) return $list;

	$keys = array_keys($list);
	shuffle($keys);
	$random = array();
	foreach ($keys as $key)
		$random[$key] = $list[$key];

	return $random;
}
$db_rand = shuffle_assoc($db);
?>
<div class="container" id="maintenance">

<style>
	#maintenance .card-panel {width:300px;--tw-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05); box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow)!important;border-radius:28px;margin-left: 10px;}
	#maintenance .cards {white-space:nowrap;overflow-x:scroll;}
	#maintenanceModal {
		border-radius: 28px!important;
		position: fixed;
		user-select: none;
		margin: 10px!important;
		height:calc(auto + 15px)!important;
		max-height:unset!important;
		min-height: unset!important
	}
	#maintenanceModal::before {
		width: 50px;
		height: 5px;
		content: "";
		z-index:999;
		cursor: pointer;
		margin: auto;
		margin-top: 10px;
		background: #ccc;
		border-radius: 9999px;
		display: block;
		position: fixed;
		pointer-events: none;
		left: 50%;
		transform: translateX(-50%)
	}
	#maintenanceModal:active::before {
		background: #aaa!important;
	}
	@media only screen and (min-width: 992px) {
		#maintenanceModal {
			width: 50vw!important;
			margin:auto!important;
			margin-bottom: 10px!important;
		}
	}
	@media only screen and (max-width: 992px) {
		#maintenanceModal {
			width: calc(100% - 20px) !important
		}
	}
	</style>
<h5>Recommended</h5>

<p>This week</p>
<div class="cards">
	<?php 
		foreach ($db_rand as $k=>$res) {
			if($res->repeat == 7) {
	?>
		<div class="card-panel waves-effect" onmousedown="showMaintenance(this)" data-id="<?=$k;?>">
			<p><b><?=$res->name;?></b></p>
			<div class="chip"><?=$res->category?></div>
		</div>
	<?php } } ?>
</div>


<p>This month</p>
<div class="cards">
	<?php 
		foreach ($db_rand as $k=>$res) {
			if($res->repeat == 30) {
	?>
		<div class="card-panel waves-effect" onmousedown="showMaintenance(this)" data-id="<?=$k;?>">
			<p><b><?=$res->name;?></b></p>
			<div class="chip"><?=$res->category?></div>
		</div>
	<?php } } ?>
</div>

<p>90 days</p>
<div class="cards">
	<?php 
		foreach ($db_rand as $k=>$res) {
			if($res->repeat == 90) {
	?>
		<div class="card-panel waves-effect" onmousedown="showMaintenance(this)" data-id="<?=$k;?>">
			<p><b><?=$res->name;?></b></p>
			<div class="chip"><?=$res->category?></div>
		</div>
	<?php } } ?>
</div>

<p>180 days</p>
<div class="cards">
	<?php 
		foreach ($db_rand as $k=>$res) {
			if($res->repeat == 180) {
	?>
		<div class="card-panel waves-effect" onmousedown="showMaintenance(this)" data-id="<?=$k;?>">
			<p><b><?=$res->name;?></b></p>
			<div class="chip"><?=$res->category?></div>
		</div>
	<?php } } ?>
</div>


<p>This year</p>
<div class="cards">
	<?php 
		foreach ($db_rand as $k=>$res) {
			if($res->repeat == 365) {
	?>
		<div class="card-panel waves-effect" onmousedown="showMaintenance(this)" data-id="<?=$k;?>">
			<p><b><?=$res->name;?></b></p>
			<div class="chip"><?=$res->category?></div>
		</div>
	<?php } } ?>
</div>
</div>
<div id="maintenanceModal" class="modal bottom-sheet"></div>
<script>
function showMaintenance(el) {
	var id = el.getAttribute("data-id")
	M.Modal.init(document.getElementById("maintenanceModal"));
	document.getElementById("maintenanceModal").innerHTML = '\n      <center>\n        <div class="loader">\n          <svg viewBox="0 0 32 32" width="42" height="42">\n            <circle id="spinner" cx="16" cy="16" r="14" fill="none"></circle>\n          </svg>\n        </div>\n      </center>'
	fetch("./user/maintenance-db.json")
		.then(res => res.json())
		.then(res => {
			M.Modal.getInstance(document.getElementById("maintenanceModal")).open();
			document.getElementById("maintenanceModal").innerHTML = `
			<div class="modal-content">
				<h4 class="center" style="margin-top: 20px;font-size: 30px;margin-bottom:20px">${res[id].name}</h4>
				<p class="center" style="opacity:.5">Repeat every ${res[id].repeat} days</p>
				<center>
					<a class="btn btn-floating btn-flat waves-effect transparent" target="_blank" href="https://google.com/search?q=${encodeURIComponent("How to " + res[id].name.toLowerCase())}">
						<i class="material-icons black-text">travel_explore</i>
					</a>
					<a class="btn btn-floating btn-flat waves-effect transparent">
						<i class="material-icons black-text">add_task</i>
					</a>
				</center><br>
				<div class="divider"></div>
				<p>Items required</p>
				${res[id].itemsNeeded.length==0?"<i>No items required</i>":""}
				${res[id].itemsNeeded.map(item => {
					return `<label style="display:block">
										<input type="checkbox" class="filled-in"/>
										<span>${item}</span>
									</label>`;
				}).join()}
			</div>
			`
		})
}
	var myBlock = document.getElementById('maintenanceModal');
var mc = new Hammer(myBlock);
mc.add( new Hammer.Pan({ direction: Hammer.DIRECTION_ALL, threshold: 0 }) );
mc.on("pandown", handleDrag);
var isDragging = false;
function handleDrag(ev) {
var elem = myBlock

// DRAG STARTED
if ( ! isDragging ) {
isDragging = true;

}
var posY = -ev.deltaY;
console.log(elem.offsetTop, window.innerHeight/1.2)
if(elem.offsetTop >= window.innerHeight/1.2 || ev.velocityY > 2) {
$(".modal").modal("close");
}
elem.style.bottom = posY + "px";
if(!/Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent) ) {

elem.addEventListener("mouseup", ()=>{
elem.style.transition="bottom .2s";
elem.style.bottom="0px";
setTimeout(()=>elem.style.transition="", 200);
})
}
}
</script>