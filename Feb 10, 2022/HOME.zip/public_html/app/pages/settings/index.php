<nav>
    <ul>
        <li><a href="javascript:void(0)" class="navbar-button material-ripple modal-close"><i class="material-icons">chevron_left</i></a></li>
    </ul>
    <ul class="right">
        <li><a href="javascript:void(0)" class="navbar-button material-ripple"><i class="material-icons">help</i></a></li>
        <li><a href="javascript:void(0)" class="navbar-button material-ripple"><i class="material-icons">search</i></a></li>
    </ul>
</nav>

<div class="mt-32" style="padding: 20px;">
    <div class="row">
        <div class="col s12 m3">
            <button class="red lighten-5 red-text material-ripple events-none btn btn-large text-darken-4 z-depth-0 settings-button"><i class="material-icons left">dark_mode</i>Appearance</button>
            <button class="transparent material-ripple btn black-text btn-large z-depth-0 settings-button"><i class="material-icons left">account_circle</i>Profile</button>
            <button class="transparent material-ripple btn black-text btn-large z-depth-0 settings-button"><i class="material-icons left">notifications</i>Notifications</button>
            <button class="transparent material-ripple btn black-text btn-large z-depth-0 settings-button"><i class="material-icons left">smartphone</i>App</button>
            <button class="transparent material-ripple btn black-text btn-large z-depth-0 settings-button"><i class="material-icons left">payments</i>Finances</button>
            <button class="transparent material-ripple btn black-text btn-large z-depth-0 settings-button"><i class="material-icons left">verified_user</i>Privacy &amp; security</button>
            <button class="transparent material-ripple btn black-text btn-large z-depth-0 settings-button"><i class="material-icons left">analytics</i>Sessions</button>
            <button class="transparent material-ripple btn black-text btn-large z-depth-0 settings-button"><i class="material-icons left">history</i>Login history</button>
            <button class="transparent material-ripple btn black-text btn-large z-depth-0 settings-button"><i class="material-icons left">room</i>Rooms</button>
            <button class="transparent material-ripple btn black-text btn-large z-depth-0 settings-button"><i class="material-icons left">label</i>Categories</button>
            <button class="transparent material-ripple btn black-text btn-large z-depth-0 settings-button"><i class="material-icons left">download</i>Backup</button>
            <button class="transparent material-ripple btn black-text btn-large z-depth-0 settings-button"><i class="material-icons left">policy</i>Legal</button>
        </div>
        <div class="col s12 m7">
            <?php include("./pages/index.php");?>
        </div>
    </div>
</div>