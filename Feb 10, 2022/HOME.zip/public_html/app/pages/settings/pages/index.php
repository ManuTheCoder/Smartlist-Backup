<main class="container">
    <h4>Appearance</h4>
    <div class="row">
        <div class="col s6"><div onclick="removeDarkMode()" class="card card-border card-rounded z-depth-0 material-ripple"><div class="card-content">
            Light
        </div></div></div>
        <div class="col s6"><div onclick="setDarkMode()" class="card card-rounded z-depth-0 grey darken-4 white-text material-ripple material-ripple@light" style="border:1px solid transparent"><div class="card-content">
            Dark
        </div></div></div>
    </div>
</main>
<script>
    function setDarkMode() {
        document.cookie = "dark=true";
        document.documentElement.classList.add("_dark")
    }
    function removeDarkMode() {
        document.cookie = "dark=false";
        document.documentElement.classList.remove("_dark")
    }
</script>