<?php
ini_set('display_errors', 1);
if (!defined('CURL_HTTP_VERSION_3')) {
    define('CURL_HTTP_VERSION_3', 30);
}
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.smartlist.ga/v2/items/starred/',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_3,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => 'token='.$_COOKIE['UserToken'],
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/x-www-form-urlencoded'
  ),
));
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($curl, CURLOPT_POSTFIELDS, 'token='.$_COOKIE['UserToken']);

$items = json_decode(curl_exec($curl))->data;

curl_close($curl);
?>
<div style="padding:20px"><h5 class="my-6 ml-2">Starred</h5>
<div class="grid">
<?php foreach($items as $item) {?>
            <div
                class="grid-item-3 card card-border card-rounded z-depth-0 material-ripple card-panel"
                data-id="<?=intval($item->id)?>"
                data-star="<?=intval($item->star)?>"
                data-lastUpdated="<?=htmlspecialchars($item->lastUpdated)?>"
                data-sync="<?=htmlspecialchars($item->sync)?>"
                data-room="<?=htmlspecialchars($item->room)?>"
                data-categories="<?=htmlspecialchars($item->categories)?>"
                style="cursor:pointer"
                onclick="item(this)">
                <h5 class="field my-4" style="max-width:20vw;"><?=htmlspecialchars($item->title)?></h5>
                <span class="field grey-text text-darken-2" style="max-width:20vw;"><?php if(empty($item->amount)) {?><span class="empty"></span><?php } ?><?=htmlspecialchars($item->amount)?></span>
                <span class="date hide"><?=htmlspecialchars($item->lastUpdated);?></span>
                <div class="mt-2"><?php 
                $d = explode(",", $item->categories); 
                if(!empty($d) && $item->categories !== "No Category Specified") {
                foreach($d as $category){
                    if(!empty($category)) {
                ?>
                <div class="chip chip-border"><?=htmlspecialchars($category);?></div>
                <?php } } } ?>
                </div>
            </div>
        <?php
        }?>
        </div>
</div>
<script>
var elem = document.querySelector('.grid');
var msnry = new Masonry( elem, {
  // options
  itemSelector: '.grid-item',
  columnWidth: 200
});

// element argument can be a selector string
//   for an individual element
var msnry = new Masonry( '.grid', {
  // options
});
</script>