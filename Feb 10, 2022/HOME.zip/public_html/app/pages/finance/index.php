<?php
ini_set('display_errors', 1);
if (!defined('CURL_HTTP_VERSION_3')) {
    define('CURL_HTTP_VERSION_3', 30);
}
function ordinal($number) {
    $ends = array('th','st','nd','rd','th','th','th','th','th','th');
    if ((($number % 100) >= 11) && (($number%100) <= 13))
        return $number. 'th';
    else
        return $number. '<sup>'.$ends[$number % 10].'</sup>';
}
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.smartlist.ga/v2/finances/',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_3,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => 'token='.$_COOKIE['UserToken'],
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/x-www-form-urlencoded'
  ),
));
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($curl, CURLOPT_POSTFIELDS, 'token='.$_COOKIE['UserToken']);

$financeData = json_decode(curl_exec($curl));

curl_close($curl);



$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.smartlist.ga/v2/account/info/',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_3,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => 'token='.$_COOKIE['UserToken'],
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/x-www-form-urlencoded'
  ),
));
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($curl, CURLOPT_POSTFIELDS, 'token='.$_COOKIE['UserToken']);

$userData = json_decode(curl_exec($curl))->data;

curl_close($curl);

function returnUniqueProperty($array,$property) {
  $tempArray = array_unique(array_column($array, $property));
  $moreUniqueArray = array_values(array_intersect_key($array, $tempArray));
  return $moreUniqueArray;
}
?>
<div class="lg-p-10">
    <header class="header green darken-3 center white-text" id="header" style="background:url(https://i.ibb.co/Lp2PnkH/blurry-gradient-haikei-1.png);background-size:cover;background-repeat:no-repeat">
        <h1><?=$userData->currency;?>127</h1>
        <h6>out of <?=$userData->currency;?><?=$userData->budget;?></h6>
        <section class="mt-5" style="white-space:nowrap;overflow-x:scroll;width:100%"><div class="container">
            <button class="z-depth-0 material-ripple material-ripple@light btn z-depth-0 btn-rounded" style="margin:5px;background:rgba(0, 0, 0,.1)">Today</button>
            <button class="z-depth-0 material-ripple material-ripple@light btn z-depth-0 btn-rounded" style="margin:5px;background:rgba(0, 0, 0,.1)">Week</button>
            <button class="z-depth-0 material-ripple material-ripple@light btn z-depth-0 btn-rounded" style="margin:5px;background:rgba(0, 0, 0,.1)">Month</button>
            <button class="z-depth-0 material-ripple material-ripple@light btn z-depth-0 btn-rounded" style="margin:5px;background:rgba(0, 0, 0,.1)">Year</button>
            <button class="z-depth-0 material-ripple material-ripple@light btn z-depth-0 btn-rounded" style="margin:5px;background:rgba(0, 0, 0,.1)">All</button>
        </div></section>
    </header>
</div>
<div style="padding: 20px;">
<div class="row">
    <section class="dark-text-white col s6 m4 no-padding" style="padding-right:10px!important"><div class="cursor-pointer card-border material-ripple card-rounded card card-panel z-depth-0 material-ripple"><h5 class="my-2">Bills</h5></div></section>
    <section class="dark-text-white col s6 m4 no-padding" style="padding-right:10px!important"><div class="cursor-pointer card-border material-ripple card-rounded card card-panel z-depth-0 material-ripple"><h5 class="my-2">Insights</h5></div></section>
    <section class="dark-text-white col s6 m4 no-padding" style="padding-right:0!important"><div class="cursor-pointer card-border material-ripple card-rounded card card-panel z-depth-0 material-ripple"><h5 class="my-2">Lessons</h5></div></section>
</div>
<div class="material-sidenav sidenav-margin" id="expense_list">
    <nav style="border-radius: 20px;position:absolute;">
        <ul>
            <li><a class="material-ripple sidenav-close navbar-button"><i class="material-icons">chevron_left</i></a></li>
        </ul>
        <ul class="right">
        </ul>
    </nav><br><br><br>
        <?php 
        $d = returnUniqueProperty($financeData->data, 'date');
        foreach($d as $data) {
            $now = new DateTime();
            $date = DateTime::createFromFormat('m/d/Y', $data->date);
            ?>
            <section class="section">
                <h4 style="text-align: right"><?=$date->format('F');?> <?=ordinal(intval($date->format("d")));?></h4>
                <div class="divider"></div>
            </section>
            <?php 
            foreach($financeData->data as $expense) {
            $expenseDate = DateTime::createFromFormat('m/d/Y', $expense->date);
            if($expenseDate == $date) {
            ?>
            <div class="card z-depth-0 grey lighten-4 mb-3 card-panel w-full" style="border-radius: 20px;">
                <h6 class="my-1 mb-3 right" style="opacity: .5;font-size:15px;"><?=$expense->date?></h6>
                <h5 class="my-1 mb-3" style="font-size:20px"><?=$expense->spentOn?></h5>
                <button class="btn material-ripple transparent right btn-floating z-depth-0" style="opacity: .3"><i class="black-text material-icons dark-text-white">more_vert</i></button>
                <p class="grey-text dark-text-white text-darken-3"><?=$userData->currency;?><?=$expense->amount?></p>
            </div>
            <?php }} ?>
        <?php } ?>
</div>
<div class="mt-3">
    <div class="row">
        <section class="col s12 m6">
            <h5 class="my-5">Recent</h5>
            <ul class="collection">
            <?php foreach(array_slice($financeData->data, 0, 5) as $k=>$data) {?>
                <div class="collection-item avatar" style="<?=($k==4?'border:0':'')?>">
                    <i class="material-icons circle blue lighten-4 black-text mt-2" style="border-radius:5px;font-size:23px;">home</i>
                    <div class="ml-2">
                        <h6 class="my-1 mb-3" style="font-size:18px"><?=$data->spentOn?></h6>
                        <p class="grey-text dark-text-white text-darken-2"><?=$userData->currency;?><?=$data->amount?></p>
                    </div>
                </div>
            <?php } ?>
            <button class="btn blue-grey lighten-5 large black-text z-depth-0 btn-rounded w-full material-ripple" onclick="M.Sidenav.getInstance(document.querySelector('#expense_list')).open()">View expenses</button>
            </ul>
        </section>
        <section class="col s12 m6">
            <h5 class="my-5">Goals</h5>
            <div class="card card-panel z-depth-0 material-ripple" style="background:rgba(200,200,200,.2);border-radius:10px;" onclick="ViewGoal(1)">
                <h6 class="my-3">🚀  Buy a home</h6>
                <p class="my-2" style="opacity: .7">$69 / $696969 raised</p>
                <div class="progress" style="background:rgba(200,200,200,.3)">
                    <div class="determinate" style="background:rgb(var(--user-theme-regular));width:69%"></div>
                </div>
            </div>
            <div class="card card-panel z-depth-0 material-ripple" style="background:rgba(200,200,200,.2);border-radius:10px;" onclick="ViewGoal(1)">
                <h6 class="my-3">🚘  Buy a car</h6>
                <p class="my-2" style="opacity: .7">$69 / $696969 raised</p>
                <div class="progress" style="background:rgba(200,200,200,.3)">
                    <div class="determinate" style="background:rgb(var(--user-theme-regular));width:29%"></div>
                </div>
            </div>
            <div class="card card-panel z-depth-0 material-ripple" style="background:rgba(200,200,200,.2);border-radius:10px;" onclick="ViewGoal(1)">
                <h6 class="my-3">🔥  Save money for something special extra long title lorem ipsum</h6>
                <p class="my-2" style="opacity: .7">$69 / $696969 raised</p>
                <div class="progress" style="background:rgba(200,200,200,.3)">
                    <div class="determinate" style="background:rgb(var(--user-theme-regular));width:29%"></div>
                </div>
            </div>
        </section>
        </div>
    </div>
</div>
</div>
<div id="view_goal" class="sidenav-margin material-sidenav black white-text">
    <nav>
        <ul><li><button class="navbar-button transparent btn sidenav-close material-ripple white-text material-ripple@light"><i class="material-icons">chevron_left</i></button></li><li><a>Buy a car</a></li></ul>
        <ul class="right"><li><button class="navbar-button transparent btn material-ripple white-text material-ripple@light"><i class="material-icons">more_vert</i></button></li></ul>
    </nav>
    <canvas id="CanvasCongrats" style="position:fixed;top:0;left:0;width:100%;height:100%;z-index:-1"></canvas>
    <div class="center valign-wrapper" style="display:flex;align-items:center;justify-content:center;flex-direction:column;height:100%;position:absolute;top:0;left:0;width:100%">
        <div class="container">
            <div style="display:flex;align-items:center;gap:10px;justify-content:center;">
                <button class="z-depth-0 transparent btn-floating material-ripple material-ripple@light white-text"><i class="material-icons">remove</i></button>
                <h2>$400</h2>
                <button class="z-depth-0 transparent btn-floating material-ripple material-ripple@light white-text"><i class="material-icons">add</i></button>
            </div>
            <h3 style="opacity: .6">out of $2900</h3>
            <h5 style="opacity: .6">14%</h5>
        </div>
    </div>
</div>
<script>
    M.Sidenav.init(document.querySelectorAll("#expense_list, #view_goal"), {
        edge: "right",
        onOpenStart: (e) => {changeThemeColor((window.innerWidth>992?"#7a7a7a":"#fff"));e.classList.add("show")},
        onCloseStart: (e) => {changeThemeColor("default");e.classList.remove("show")}
    })
    function ViewGoal(id) {
        M.Sidenav.getInstance(document.getElementById("view_goal")).open();
        setTimeout(() => {
            var canvas = document.getElementById('CanvasCongrats');
            canvas.confetti = canvas.confetti || confetti.create(canvas, { resize: true });
            canvas.confetti({
                spread: 100,
                particleCount: 200,
                origin: { y: 1 }
            });
        }, 200)
    }
</script>