function getHashPage() {
  var file =
    _pages[window.location.hash.replace("#", "")] || _user.preferences.homePage;
  if (document.querySelector(".bottom-nav-active")) {
    document
      .querySelectorAll(".bottom-nav-active")
      .forEach((d) => d.classList.remove("bottom-nav-active"));
  }
  if(document.querySelector(`#sidenav-drawer a[href='${window.location.hash}']`)) {
      let d = document.querySelector(`#sidenav-drawer a[href='${window.location.hash}']`);
      d.click();
function isScrolledIntoView(el) {
    var rect = el.getBoundingClientRect();
    var elemTop = rect.top;
    var elemBottom = rect.bottom;

    // Only completely visible elements return true:
    var isVisible = (elemTop >= 0) && (elemBottom <= window.innerHeight);
    // Partially visible elements return true:
    //isVisible = elemTop < window.innerHeight && elemBottom >= 0;
    return isVisible;
}
if(!isScrolledIntoView(d)){
      d.scrollIntoView({
            behavior: 'auto',
            block: 'center',
            inline: 'center'
        })
}
  }
  if (
    !window.location.hash ||
    window.location.hash.includes("dashboard") ||
    window.location.hash.includes("home")
  ) {
    document
      .getElementById("bottomNav.link1")
      .classList.add("bottom-nav-active");
  }
  if (window.location.hash.includes("finances")) {
    document
      .getElementById("bottomNav.link2")
      .classList.add("bottom-nav-active");
  }
  if (window.location.hash.includes("notifications")) {
    document
      .getElementById("bottomNav.link4")
      .classList.add("bottom-nav-active");
  }
  if (window.location.hash.includes("meal-planner")) {
    document
      .getElementById("bottomNav.link5")
      .classList.add("bottom-nav-active");
  }
  var app = document.getElementById("app");
  if(window.innerWidth < 992) app.innerHTML = loader;
  window._t = setTimeout(() => document.getElementById("app").innerHTML=loader,1000)
  fetch(file)
    .then((res) => (res.status == 404 ? res : res.text()))
    .then((res) => {
      if (res.status === 404) {
        clearTimeout(window._t)
        app.innerHTML = `
			<div class="loader-container" style="margin-top: -64px">
				<div class="container center">
				<h4>Uh oh!</h4>
			    <p class="grey-text text-darken-2">We couldn't load the page you asked for. Try reloading this page if it might help</p>
				</div>
			</div>
			`;
      } else {
        app.innerHTML = res;
        executeScriptElements(document.getElementById("app"));
        clearTimeout(window._t)
      }
    })
    .catch((err) => alert(err));
  return file;
}
window.addEventListener("hashchange", getHashPage);
window.addEventListener("load", getHashPage);
export { getHashPage };
