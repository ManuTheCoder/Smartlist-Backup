window.addEventListener("load", () => {
M.Modal.init(document.querySelectorAll(".modal"), {
	outDuration: 200,
	inDuration: 200,
	onOpenStart: () => changeThemeColor("#808080"),
	onCloseStart: () => changeThemeColor("default"),
});
M.Modal.init(document.getElementById("add.item"), {
	outDuration: 200,
	inDuration: 200,
	onOpenStart: () => changeThemeColor("#808080"),
    onOpenEnd: () => document.getElementById('add.item.form.name').focus(),
	onCloseStart: () => changeThemeColor("default"),
    onCloseEnd: () => document.getElementById('add.item.form').reset()
});
M.Modal.init(document.getElementById("viewAccount"), {
	opacity: (window.innerWidth>992 ? 0: .5),
	onOpenStart: () => {if (window.innerWidth < 992) {changeThemeColor("#808080")}},
	onCloseStart: () => changeThemeColor("default"),
});

M.Modal.init(document.getElementById("search"), {
	onOpenStart: () => changeThemeColor((window.innerWidth > 992 ? "#808080": "#fff")),
	onCloseStart: () =>
		{changeThemeColor("default");document.querySelector("#searchResults").classList.remove("active")},
});

M.Modal.init(document.getElementById("settings"), { 
	onOpenStart: () => {
        changeThemeColor("#fff");
        fetch("/app/pages/settings/")
            .then(res => res.text())
            .then(res => {
                document.getElementById("settings").innerHTML = res;
                executeScriptElements(document.getElementById("settings"))
            })
    },
	onCloseStart: () =>
		{changeThemeColor("default")},
});

M.Dropdown.init(document.querySelector('.dropdown-trigger'), {
	constrainWidth: false,
    container: document.body,
    inDuration: (window.innerWidth > 992 ? 0 : .5),
    outDuration: (window.innerWidth > 992 ? 0 : .5),
})

M.Datepicker.init(document.querySelectorAll(".datepicker"), {
	container: document.body,
	minDate: new Date(),
	showDaysInNextAndPreviousMonths: true,
	showClearBtn: true,
	autoClose: true,
})

M.Sidenav.init(document.querySelectorAll(".sidenav"), {
	// onOpenStart: () => changeThemeColor("#808080"),
	onCloseStart: () => changeThemeColor("default"),
	inDuration: 200,
});
M.FormSelect.init(document.querySelectorAll("select"), {
	
});
});
M.Collapsible.init(document.querySelectorAll('.collapsible'))