<?php
class UserData extends App {
  protected function verify($data) {
    try {
        $dbh = new PDO("mysql:host=" . App::server . ";dbname=" . App::database, App::user, App::password);
        $dbh->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        $sql = $dbh->prepare("SELECT * FROM UserTokens WHERE token=:token");
        $sql->execute(array(
            ":token" => $data
        ));
        $users = $sql->fetchAll();
        $obj = new stdClass();
        $obj->valid = count($users) == 1 ? true:false;
        $obj->data = $users;
        return $obj;
    }
    catch (PDOException $e) {var_dump($e);}
  }
  public function fetchData($token) {
      $verification = $this->verify($token);
      if(!$verification->valid) {
          throw new Error("User Token is invalid!");
      }
      $id = $verification->data[0]['user'];

      try {
            $dbh = new PDO("mysql:host=" . App::server . ";dbname=" . App::database, App::user, App::password);
            $dbh->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
            $sql = $dbh->prepare("SELECT * FROM Accounts WHERE id=:id");
            $sql->execute(array(
                ":id" => $id
            ));
            $users = $sql->fetchAll();
            return $users;
        }
        catch (PDOException $e) {var_dump($e);}
    }
}